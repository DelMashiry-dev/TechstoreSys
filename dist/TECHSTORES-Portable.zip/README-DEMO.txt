IT-DIR Tech Stores — Portable Demo Package
==========================================

WHAT THIS IS
  A self-contained Windows demo of the IT-DIR Tech Stores system.
  Python is NOT required on the target computer.

HOW TO RUN (on the Director's PC)
  1. Copy the entire TECHSTORES-Portable folder (USB / shared drive).
  2. Double-click START-DEMO.bat
     (or double-click TECHSTORES.exe)
  3. The browser opens to http://127.0.0.1:8080/app/
  4. Keep the black console window open while demonstrating.
  5. Close that window (or press Ctrl+C) to stop.

DEMO LOGINS
  admin / admin123     — full administrator
  dir   / dir123       — Director IT Dir
  store / store123     — store officer
  viewer / view123     — read-only viewer

DATA
  All saves go into techstores.db in this same folder.
  That file travels with the folder if you copy it again later.

NOTES
  - Windows Defender may prompt the first time — choose Run anyway
    (unsigned local demo build).
  - Port 8080 must be free on the PC.
  - Do not move TECHSTORES.exe out of this folder; it needs app\.

Built for offline / local demonstration only.
