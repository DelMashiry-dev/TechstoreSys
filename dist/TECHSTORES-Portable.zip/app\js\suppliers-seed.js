/* suppliers-seed.js — IT-DIR official supplier / contact list extracted from RESTRICTED registers */

const IT_DIR_SUPPLIERS_SOURCE =
    'IT DIR. Supply and Delivery of Computers, Printers, Photocopiers and Accessories (2022) + contact registers';

/** Official extracted suppliers: { name, phone, notes? } */
const IT_DIR_SUPPLIERS_SEED = [
    // Page 1 — computers / printers / photocopiers register
    { name: 'Jennilim', phone: '0776557036 / 0732375344' },
    { name: 'Burnshiford', phone: '0772780817' },
    { name: 'Anamay Distributors', phone: '0713412333 / 0772764230 / 0772998643' },
    { name: 'Realtech', phone: '0778768578 / 0775026028' },
    { name: 'Lifemark Computers', phone: '0772676290 / 0772676292' },
    { name: 'Findtech', phone: '0772338588' },
    { name: 'Vestech Computers', phone: '0772745678' },
    { name: 'Upright Technology', phone: '0785583869 / 0712773881' },
    { name: 'Lumarch', phone: '0738521199' },
    { name: 'Partoc', phone: '0772448443' },
    { name: 'Stenpaid Enterprises', phone: '0773650624 / 0774975792' },
    { name: 'Eveluck Suppliers', phone: '0774339332 / 0733244341' },
    { name: 'Infosys Technologies', phone: '0772622857 / 077278760' },
    { name: 'Norkom Technologies', phone: '0772622857' },
    { name: 'Laserjet Impressions', phone: '751315 / 759967 / 0772335976' },
    { name: 'Natlarks Technology', phone: '0773925179 / 0775425284' },
    { name: 'Glossup', phone: '0783312877' },
    { name: 'Rinfotek', phone: '0772762127' },
    { name: 'Maxpro', phone: '0719780827' },
    { name: 'Staman Investments', phone: '0772316512' },
    { name: 'Shakeline Investments', phone: '0772352988' },
    { name: 'Fistpack', phone: '0772444847' },
    { name: 'Wilvex', phone: '0772868760' },
    { name: 'Skihold Investments', phone: '0772471601 / 0776557036' },
    { name: 'Smacper', phone: '0774089531 / 0717952323' },
    { name: 'Techhub Technologies', phone: '0773373218' },
    { name: 'Ridgelight', phone: '0772614482' },
    { name: 'Dampack', phone: '0772974334' },
    { name: 'Light House', phone: '0784042990' },
    { name: 'Maxo', phone: '0714412853', notes: 'Contact noted on register cover' },

    // Page 2 — supplier contact register
    { name: 'Best Brands Wholesalers', phone: '0774296456' },
    { name: 'Usewax Enterprises', phone: '0771858422' },
    { name: 'Davetronics', phone: '0773279139 / 0772930400' },
    { name: 'Draxler', phone: '0775555620 / 0779195813' },
    { name: 'Julpro', phone: '0774751586' },
    { name: 'Perique', phone: '0782847313' },
    { name: 'Taiho Investments', phone: '07752443007' },
    { name: 'Nasraq', phone: '0772570432' },
    { name: 'Encewood', phone: '0773267852' },
    { name: 'Promax', phone: '0774773577' },
    { name: 'Tagadi Business', phone: '0784864484 / 0784864490' },
    { name: 'Paramount Gold', phone: '0773421629' },
    { name: 'Recon Technologies', phone: '0775576402' },
    { name: 'Foster Tech', phone: '0774557181' },
    { name: 'Metflare Investment', phone: '0773588030' },
    { name: 'Philpport Technologies', phone: '0772317578' },
    { name: 'Satewave Technologies', phone: '0777267267' },
    { name: 'Rosley Investments', phone: '0772261036 / 0719261036' },
    { name: 'Sector Resources', phone: '0785082769' },
    { name: 'Gudtech', phone: '0777168070' },
    { name: 'Honest Passion Technologies', phone: '0738521199' },
    { name: 'CN Stationers', phone: '0772995008' },
    { name: 'PLEJO', phone: '0772495538' },
    { name: 'Frolgate Technologies', phone: '0772133068 / 0772100982' },
    { name: 'Deloff Computers', phone: '0242770646 / 0242770647' },
    { name: 'Leafshire Investments', phone: '0788666436' },
    { name: 'Vanchang Investments', phone: '0775958223' },
    { name: 'Lecare Investments', phone: '0717888840 / 0712339386' },
    { name: 'Ideas Enterprises', phone: '0772345252 / 0772357490' },
    { name: 'Executive Decision', phone: '0772810359 / 0772894049' },

    // Page 3 — continuation
    { name: 'Chalsam Enterprises', phone: '0777704783 / 0719810359' },
    { name: 'MackinPRG Agencies', phone: '0773688648 / 0772362482' },
    { name: 'Nastpack Stationery Hub', phone: '0773263661 / 0775292877' },
    { name: 'CHANNMEAL', phone: '0772433895 / 0772698720' },
    { name: 'BIZMOON', phone: '0774340947 / 07734118810' },
    { name: 'Pamflow Investments', phone: '0772595769 / 0712547631' },
    { name: 'Overview Technologies', phone: '0772403998' }
];

function normalizeSupplierNameKey(name) {
    return String(name || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, ' ')
        .trim();
}

function mergeSupplierPhoneLists(existing, incoming) {
    const parts = `${existing || ''} / ${incoming || ''}`
        .split(/[/,;|]+/)
        .map((p) => p.trim())
        .filter(Boolean);
    const seen = new Set();
    const unique = [];
    parts.forEach((p) => {
        const key = p.replace(/\s+/g, '');
        if (seen.has(key)) return;
        seen.add(key);
        unique.push(p);
    });
    return unique.join(' / ');
}

/**
 * Import official IT-DIR supplier contacts into the suppliers table.
 * @returns {{ added: number, updated: number, total: number }}
 */
function importOfficialSuppliersList({ replace = false } = {}) {
    const tbody = document.getElementById('suppliers-table-body');
    if (!tbody) return { added: 0, updated: 0, total: 0 };

    if (replace) tbody.innerHTML = '';

    const existingRows = typeof collectSupplierRows === 'function' ? collectSupplierRows() : [];
    const byName = new Map();
    existingRows.forEach((row) => {
        byName.set(normalizeSupplierNameKey(row.name), row);
    });

    let added = 0;
    let updated = 0;
    const year = new Date().getFullYear();
    let nextId = existingRows.length + 1;

    IT_DIR_SUPPLIERS_SEED.forEach((seed) => {
        const key = normalizeSupplierNameKey(seed.name);
        const existing = byName.get(key);
        if (existing) {
            const tr = tbody.rows[existing.index];
            if (!tr) return;
            const phoneInput = tr.querySelectorAll('input:not([type="hidden"])')[3];
            const notesInput = tr.querySelector('.supplier-notes-field');
            if (phoneInput) {
                phoneInput.value = mergeSupplierPhoneLists(phoneInput.value, seed.phone);
            }
            if (notesInput && seed.notes && !notesInput.value.includes(seed.notes)) {
                notesInput.value = [notesInput.value, seed.notes].filter(Boolean).join(' · ');
            }
            updated += 1;
            return;
        }

        const id = `SUP-${year}-${String(nextId).padStart(3, '0')}`;
        nextId += 1;
        const tr = buildSupplierRow({
            id,
            name: seed.name,
            contact: '',
            phone: seed.phone,
            email: '',
            start: '',
            end: '',
            status: 'Active',
            notes: [IT_DIR_SUPPLIERS_SOURCE, seed.notes].filter(Boolean).join(' · ')
        });
        tbody.appendChild(tr);
        byName.set(key, { name: seed.name });
        added += 1;
    });

    return {
        added,
        updated,
        total: typeof collectSupplierRows === 'function' ? collectSupplierRows().length : tbody.rows.length
    };
}
