/* utils.js — toast, currency, serialize/restore */

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3200);
}

function formatCurrency(amount) {
    return '$' + Number(amount || 0).toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

function isInputElement(el) {
    return el && (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA');
}

function serializeField(el) {
    if (el.type === 'file') return null;
    const data = {
        tag: el.tagName.toLowerCase(),
        type: el.type || '',
        value: el.value
    };
    if (el.id) data.id = el.id;
    if (el.type === 'checkbox' || el.type === 'radio') {
        data.checked = !!el.checked;
    }
    if (el.tagName === 'SELECT') {
        data.selectedIndex = el.selectedIndex;
    }
    return data;
}

function applyField(el, data) {
    if (!data || !el) return;
    if (el.type === 'file') return;
    if (el.type === 'checkbox' || el.type === 'radio') {
        el.checked = !!data.checked;
        return;
    }
    el.value = data.value ?? '';
    if (el.tagName === 'SELECT' && typeof data.selectedIndex === 'number') {
        el.selectedIndex = data.selectedIndex;
    }
}

function serializeModule(moduleId) {
    const container = document.getElementById(moduleId);
    if (!container) return null;

    const fields = [];
    container.querySelectorAll('input, select, textarea').forEach((el) => {
        if (el.closest('tbody')) return;
        if (el.type === 'file') return;
        fields.push(serializeField(el));
    });

    const tables = {};
    container.querySelectorAll('tbody[id]').forEach((tbody) => {
        if (tbody.getAttribute('data-inventory-view') === '1') return;
        tables[tbody.id] = serializeTableBody(tbody);
    });

    return { fields, tables };
}

function serializeTableBody(tbody) {
    const rows = [];
    tbody.querySelectorAll('tr').forEach((tr) => {
        const row = { cells: [], staticCells: [] };
        tr.querySelectorAll('td').forEach((td) => {
            const input = td.querySelector('input, select, textarea');
            if (input) {
                row.cells.push(serializeField(input));
            } else {
                row.staticCells.push(td.textContent.trim());
            }
        });
        rows.push(row);
    });
    return rows;
}

function restoreModule(moduleId, moduleData) {
    const container = document.getElementById(moduleId);
    if (!container || !moduleData) return;

    const fieldElements = [];
    container.querySelectorAll('input, select, textarea').forEach((el) => {
        if (el.closest('tbody')) return;
        if (el.type === 'file') return;
        fieldElements.push(el);
    });

    (moduleData.fields || []).forEach((field, index) => {
        applyField(fieldElements[index], field);
    });

    Object.entries(moduleData.tables || {}).forEach(([tbodyId, rows]) => {
        restoreTableBody(tbodyId, rows);
    });
}

function restoreTableBody(tbodyId, rows) {
    const tbody = document.getElementById(tbodyId);
    if (!tbody) return;

    tbody.innerHTML = '';
    if (!rows || rows.length === 0) {
        const builder = ROW_BUILDERS[tbodyId];
        if (builder) tbody.appendChild(builder());
        return;
    }

    rows.forEach((rowData, rowIndex) => {
        if (tbodyId === 'voucher-table-body') {
            rowData = migrateVoucherRowData(rowData);
        }
        if (tbodyId === 'purchase-orders-table-body') {
            rowData = migratePurchaseOrderRowData(rowData);
        }
        if (tbodyId === 'loans-table-body') {
            rowData = migrateLoanRowData(rowData);
        }
        if (tbodyId === 'unit-equipment-table-body' && typeof migrateUnitEquipmentRowData === 'function') {
            rowData = migrateUnitEquipmentRowData(rowData);
        }
        const builder = ROW_BUILDERS[tbodyId];
        const tr = builder ? builder() : document.createElement('tr');
        if (tbodyId === 'bids-table-body' || tbodyId === 'unit-equipment-table-body' || tbodyId === 'dp-f1-table-body' || tbodyId === 'spec-eval-table-body' || tbodyId === 'zna-q-982-table-body') {
            const serialCell = tr.querySelector('td:first-child');
            if (serialCell && !serialCell.querySelector('input')) {
                serialCell.textContent = String(rowIndex + 1);
            }
        }

        const inputs = tr.querySelectorAll('input, select, textarea');
        rowData.cells.forEach((cellData, index) => {
            applyField(inputs[index], cellData);
        });

        if (tbodyId === 'unit-equipment-table-body' && typeof attachUnitEquipmentRow === 'function') {
            attachUnitEquipmentRow(tr);
        }

        tbody.appendChild(tr);
    });

    if (tbodyId === 'bids-table-body') {
        tbody.querySelectorAll('tr').forEach(attachBidRowCalculations);
    }
    if (tbodyId === 'voucher-table-body') {
        tbody.querySelectorAll('tr').forEach(attachVoucherRowCalculations);
    }
    if (STOCK_LEDGER_TBODY_IDS.includes(tbodyId)) {
        tbody.querySelectorAll('tr').forEach(attachStockLedgerRow);
        recalculateStockLedger(tbodyId);
    }
    if (tbodyId === 'gl-220200002-table-body') {
        tbody.querySelectorAll('tr').forEach(attachJobCardRowCalculations);
        recalculateJobCardTotal();
    }
    if (tbodyId === 'loans-table-body') {
        tbody.querySelectorAll('tr').forEach((tr) => {
            if (typeof attachTemporaryLoanRow === 'function') attachTemporaryLoanRow(tr);
        });
    }
    if (tbodyId === 'zna-q-178-table-body' && typeof attachZnaQ178RowCalc === 'function') {
        tbody.querySelectorAll('tr').forEach(attachZnaQ178RowCalc);
        if (typeof recalculateZnaQ178Stock === 'function') recalculateZnaQ178Stock();
    }
    if (tbodyId === 'zna-q-80-table-body' && typeof attachZnaQ80RowCalc === 'function') {
        tbody.querySelectorAll('tr').forEach(attachZnaQ80RowCalc);
        if (typeof recalculateZnaQ80Stock === 'function') recalculateZnaQ80Stock();
    }
}

/* ===== Print helpers (fix blank / stuck print preview) ===== */

function clearPrintMode() {
    document.body.classList.remove('is-printing');
    [...document.body.classList]
        .filter((c) => c.startsWith('printing-'))
        .forEach((c) => document.body.classList.remove(c));
    document.querySelectorAll('.print-target').forEach((el) => el.classList.remove('print-target'));
}

/**
 * Official form / report print. Uses afterprint cleanup (not a short timeout),
 * so Chrome/Edge preview is not left with visibility:hidden and a blank page.
 */
function runOfficialPrint(prepare) {
    clearPrintMode();
    if (typeof prepare === 'function') prepare();

    const finish = () => {
        clearPrintMode();
        window.removeEventListener('afterprint', finish);
    };
    window.addEventListener('afterprint', finish);

    // Let the browser paint the print-target before opening the dialog
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            try {
                window.print();
            } catch (err) {
                finish();
            }
            // Fallback if afterprint never fires (some hosts)
            setTimeout(() => {
                if (document.body.classList.contains('is-printing')) finish();
            }, 2000);
        });
    });
}

function ensurePrintHost(hostId) {
    let host = document.getElementById(hostId);
    if (!host) {
        host = document.createElement('div');
        host.id = hostId;
        host.className = hostId;
        document.body.appendChild(host);
    }
    return host;
}

/**
 * Hardened "Save as PDF": prefer the module's official print path, then
 * browser Print → Save as PDF. Avoids blank preview by using runOfficialPrint.
 */
function saveModuleAsPdf(moduleId) {
    const id = moduleId || (typeof currentModuleId !== 'undefined' ? currentModuleId : '');
    if (!id) {
        showToast?.('Open a form first, then use Save PDF.', 'info');
        return;
    }
    showToast?.('Print dialog: choose “Save as PDF” / “Microsoft Print to PDF”.', 'info');

    if (typeof QM_PRINT_MAP !== 'undefined' && typeof QM_PRINT_MAP[id] === 'function') {
        try {
            QM_PRINT_MAP[id]();
            return;
        } catch (e) {
            console.warn('Official PDF print failed', e);
        }
    }

    const printBtn = document.querySelector(`#${CSS.escape(id)} .btn-print-module`)
        || document.querySelector(`.btn-print-module[data-print-target="${CSS.escape(id)}"]`);
    if (printBtn) {
        printBtn.click();
        return;
    }

    const reportBtn = document.querySelector(`#${CSS.escape(id)} .btn-generate-report`)
        || document.querySelector(`.btn-generate-report[data-report-module="${CSS.escape(id)}"]`);
    if (reportBtn) {
        reportBtn.click();
        setTimeout(() => {
            if (typeof runOfficialPrint === 'function') {
                runOfficialPrint(() => {
                    const out = document.getElementById('report-output');
                    if (out) {
                        out.classList.add('print-target');
                        document.body.classList.add('is-printing');
                    }
                });
            } else {
                window.print();
            }
        }, 400);
        return;
    }

    if (typeof runOfficialPrint === 'function') {
        runOfficialPrint(() => {
            const section = document.getElementById(id);
            if (section) {
                section.classList.add('print-target');
                document.body.classList.add('is-printing', `printing-${id}`);
            }
        });
    } else {
        window.print();
    }
}

function initSavePdfButtons() {
    document.body.addEventListener('click', (e) => {
        const btn = e.target.closest('.btn-save-pdf');
        if (!btn) return;
        e.preventDefault();
        const moduleId = btn.getAttribute('data-pdf-module')
            || btn.closest('.form-container')?.id
            || (typeof currentModuleId !== 'undefined' ? currentModuleId : '');
        saveModuleAsPdf(moduleId);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    clearPrintMode();
    initSavePdfButtons();
    // Recover if a previous print left the page blank for Ctrl+P
    window.addEventListener('beforeprint', () => {
        if (document.body.classList.contains('is-printing') && !document.querySelector('.print-target')) {
            clearPrintMode();
        }
    });
    window.addEventListener('afterprint', () => {
        if (document.body.classList.contains('is-printing')) clearPrintMode();
    });
});
