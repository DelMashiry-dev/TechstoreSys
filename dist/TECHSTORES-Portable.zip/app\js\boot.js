/* boot.js — application startup / event wiring */

function wireLoginForm() {
    const form = document.getElementById('loginForm');
    if (!form || form.dataset.loginWired === '1') return;
    form.dataset.loginWired = '1';
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        e.stopPropagation();
        setLoginError('');
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        const submitBtn = this.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Signing in...';
        }
        try {
            const result = await attemptLogin(username, password);
            if (!result.ok) {
                setLoginError(result.message);
                return;
            }
            try {
                restoreAllModules();
                updateDashboard();
                updateVoucherSummary();
                updateSystemAlerts();
            } catch (refreshError) {
                console.error('Post-login refresh failed', refreshError);
            }
            // Password renewal is optional during development — defaults stay valid.
            enterApp(result.user);
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Sign In';
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', async function() {
    // Attach login first so a later init error cannot block Sign In
    wireLoginForm();
    // Sync fallback so a fast Sign In never hits a null appState
    try {
        if (!appState) appState = loadState();
    } catch (_) {
        appState = createDefaultState();
    }

    try {
        appState = await loadStateFromDatabase();
        if (!appState.users || !appState.users.length) {
            appState.users = createDefaultUsers();
            saveState();
        } else if (typeof ensureSeedUsersPresent === 'function') {
            const before = appState.users.length;
            appState.users = ensureSeedUsersPresent(appState.users);
            if (appState.users.length !== before) {
                if (typeof saveStateNow === 'function') await saveStateNow();
                else saveState();
            }
        }
        if (!Array.isArray(appState.orderlyDailyFile)) {
            appState.orderlyDailyFile = [];
        }
        if (typeof applyPhysicalStockCount20260731 === 'function') {
            const stockResult = applyPhysicalStockCount20260731();
            if (stockResult.applied) {
                if (typeof saveStateNow === 'function') await saveStateNow();
                else saveState();
                console.info('Physical stock count applied:', stockResult.lines);
            }
        }
        if (typeof ensureExampleMidLaptopRequisition === 'function') {
            const ex = ensureExampleMidLaptopRequisition();
            if (ex) {
                if (typeof saveStateNow === 'function') await saveStateNow();
                else saveState();
            }
        }
        applyTheme(appState.theme);
        if (typeof initInventoryLedgersUi === 'function') initInventoryLedgersUi();
        if (typeof buildVoucherInventorySection === 'function') buildVoucherInventorySection();
        // Load standalone module HTML, then restore saved form values
        if (typeof preloadAllModules === 'function') {
            await preloadAllModules();
        }
        restoreAllModules();
        if (typeof initFinancialYearBidsImport === 'function') initFinancialYearBidsImport();
        initBidCalculations();
        initVoucherCalculations();
        initStockCalculations();
        initConsumablesStockCalculations();
        initJobCardCalculations();
        initTableSearch();
        initReportsModule();
        if (typeof initGlTargetMonthControls === 'function') initGlTargetMonthControls();
        initSpecEvaluationModule();
        if (typeof initRequisitionsModule === 'function') initRequisitionsModule();
        if (typeof initOrderlyRoomModule === 'function') initOrderlyRoomModule();
        if (typeof initCorrespondenceFilesModule === 'function') initCorrespondenceFilesModule();
        if (typeof initMonthlyReturnsModule === 'function') initMonthlyReturnsModule();
        if (typeof initUndeliveredModule === 'function') initUndeliveredModule();
        if (typeof initDpProcurementModule === 'function') initDpProcurementModule();
        if (typeof initUnitEquipmentModule === 'function') initUnitEquipmentModule();
        if (typeof initTemporaryLoansModule === 'function') initTemporaryLoansModule();
        if (typeof initIctAccountabilityModule === 'function') initIctAccountabilityModule();
        if (typeof initStockTakeModule === 'function') initStockTakeModule();
        if (typeof initSuppliersModule === 'function') initSuppliersModule();
        if (typeof initRepairIntakeModules === 'function') initRepairIntakeModules();
        if (typeof ensureRepairIntakeTables === 'function') ensureRepairIntakeTables();
        initFormBackButtons();
        if (typeof initStockTxnModal === 'function') initStockTxnModal();
        updateDashboard();
        updateVoucherSummary();
        if (typeof renderVoucherInventoryTables === 'function') renderVoucherInventoryTables();
        updateSystemAlerts();
        if (typeof initCommandBoard === 'function') initCommandBoard();
        if (typeof updateCommandBoard === 'function') updateCommandBoard();
        if (typeof initSystemAlertsClicks === 'function') initSystemAlertsClicks();
        updateDbStatusBadge();
        if (typeof initPersistentDatabaseHooks === 'function') initPersistentDatabaseHooks();
        if (typeof initFieldHelpSystem === 'function') initFieldHelpSystem();
    } catch (bootError) {
        console.error('Boot init failed (login still available)', bootError);
        if (bootError && bootError.stack) console.error(bootError.stack);
        if (!appState) {
            try { appState = loadState(); } catch (_) { appState = createDefaultState(); }
        }
        try { updateDbStatusBadge(); } catch (_) { /* ignore */ }
        try { if (typeof initFieldHelpSystem === 'function') initFieldHelpSystem(); } catch (_) { /* ignore */ }
    }

    document.getElementById('logoutBtn')?.addEventListener('click', logoutUser);

    document.getElementById('saveUserBtn')?.addEventListener('click', saveUserFromForm);
    document.getElementById('resetUserFormBtn')?.addEventListener('click', function() {
        document.getElementById('newUserPassword').placeholder = 'Password';
        resetUserForm();
    });

    document.getElementById('users-table-body')?.addEventListener('click', function(e) {
        const editBtn = e.target.closest('.btn-edit-user');
        const toggleBtn = e.target.closest('.btn-toggle-user');
        if (editBtn) editUser(editBtn.dataset.userId);
        if (toggleBtn) toggleUserActive(toggleBtn.dataset.userId);
    });

    const menuItems = document.querySelectorAll('.sidebar-menu a[data-target], .card[data-target]');
    const contentSections = document.querySelectorAll('.content-section, .form-container');

    // Capture-phase: always open modules on first click (Field Help must not block nav)
    document.querySelector('.sidebar-menu')?.addEventListener('click', function(e) {
        const link = e.target.closest('a[data-target]');
        if (!link || !this.contains(link)) return;
        e.preventDefault();
        const targetId = link.getAttribute('data-target');
        if (targetId) navigateToModule(targetId);
    }, true);

    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('data-target');
            if (!targetId) return;
            navigateToModule(targetId);
        });
    });

    document.querySelectorAll('.quick-action-btn, .panel-link[data-target], .rail-shortcut[data-target]').forEach((button) => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            navigateToModule(this.dataset.target);
        });
    });

    document.getElementById('refreshDashboardBtn')?.addEventListener('click', function() {
        updateDashboard();
        showToast('Dashboard refreshed.');
    });

    document.querySelectorAll('.close-btn').forEach(button => {
        button.addEventListener('click', function() {
            navigateToModule('dashboard', { skipHistory: true, clearHistory: true });
        });
    });

    contentSections.forEach(section => {
        if (section.id !== 'dashboard') {
            section.style.display = 'none';
        }
    });

    document.querySelector('.toggle-sidebar')?.addEventListener('click', function() {
        document.querySelector('.sidebar')?.classList.toggle('collapsed');
    });

    document.getElementById('themeToggle')?.addEventListener('click', function() {
        if (typeof openUiPreferences === 'function') openUiPreferences();
    });

    if (typeof initUiPreferences === 'function') initUiPreferences();

    document.querySelectorAll('.nav-submenu-toggle').forEach((toggle) => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const submenu = this.closest('li')?.querySelector('.submenu');
            if (!submenu) return;
            submenu.classList.toggle('active');
            this.classList.toggle('is-open', submenu.classList.contains('active'));
        });
    });

    document.querySelectorAll('.btn-save-module').forEach(button => {
        button.addEventListener('click', function() {
            const moduleContainer = this.closest('.form-container');
            if (moduleContainer) {
                saveModule(moduleContainer.id);
            }
        });
    });

    document.getElementById('processReleaseCutBtn')?.addEventListener('click', processReleaseCut);

    document.getElementById('voucherType')?.addEventListener('change', function() {
        updateVoucherSummary();
        if (typeof renderVoucherInventoryTables === 'function') renderVoucherInventoryTables();
    });
    document.getElementById('voucherDefaultGl')?.addEventListener('change', function() {
        document.querySelectorAll('#voucher-table-body .voucher-gl').forEach((select) => {
            if (!select.value) select.value = this.value;
        });
    });

    document.getElementById('exportDataBtn')?.addEventListener('click', exportSystemData);
    document.getElementById('importDataFile')?.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) importSystemData(file);
        event.target.value = '';
    });

    document.querySelectorAll('.btn-print-module').forEach((button) => {
        button.addEventListener('click', function() {
            printModule(this.dataset.printTarget);
        });
    });

    if (typeof initDashboardCollapsibles === 'function') initDashboardCollapsibles();

    const existingSession = loadSession();
    if (existingSession) {
        enterApp(existingSession);
    } else {
        document.body.classList.add('app-locked');
        updateHeaderUser();
    }
});

