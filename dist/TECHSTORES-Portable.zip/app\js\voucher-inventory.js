/* voucher-inventory.js — Receive / Issue stock ledger, day start/end, alerts */

function invHtmlEscape(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function ensureStoresInventory() {
    if (!appState.storesInventory) {
        appState.storesInventory = createDefaultStoresInventory();
    }
    if (!appState.storesInventory.openings) appState.storesInventory.openings = {};
    if (!Array.isArray(appState.storesInventory.transactions)) appState.storesInventory.transactions = [];
    if (!Array.isArray(appState.storesInventory.dayHistory)) appState.storesInventory.dayHistory = [];
    (VOUCHER_INVENTORY_CATEGORIES || []).forEach((cat) => {
        if (appState.storesInventory.openings[cat.key] == null) {
            appState.storesInventory.openings[cat.key] = 0;
        }
    });
    return appState.storesInventory;
}

function todayIsoDate() {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${m}-${day}`;
}

function suggestVoucherInventoryCategory(itemName) {
    if (typeof suggestInventoryLedgerKey === 'function') {
        return suggestInventoryLedgerKey(itemName);
    }
    const t = String(itemName || '').toLowerCase();
    if (!t.trim()) return null;
    if (/\b(toner|cartridge|ink|printhead|ribbon|drum)\b/.test(t)) return 'inv-toner';
    if (/\b(flash|usb\s*stick|memory\s*stick|pen\s*drive)\b/.test(t)) return 'inv-usb';
    if (/\b(external\s*(hard\s*)?(disk|drive|hdd))\b/.test(t)) return 'inv-external-hdd';
    if (/\b(software|licence|license|windows|office|kaspersky|vmware|oracle|sql|devexpress)\b/.test(t)) return 'inv-softwares';
    if (/\b(laptop|notebook)\b/.test(t)) return 'inv-laptops';
    if (/\b(desktop|optiplex)\b/.test(t)) return 'inv-desktops';
    if (/\b(tablet|ipad)\b/.test(t)) return 'inv-tablets';
    if (/\b(printer|mfp)\b/.test(t)) return 'inv-printers';
    if (/\b(projector)\b/.test(t)) return 'inv-projectors';
    if (/\b(smart\s*board|interactive)\b/.test(t)) return 'inv-smartboards';
    if (/\b(motherboard|ssd|ram|ddr|fuser|roller|maintenance\s*kit|fan|battery|solder|blower|spare)\b/.test(t)) return 'inv-spares';
    if (/\b(photocopier|reballing|plotter|fire\s*alarm|id\s*card|maintenance)\b/.test(t)) return 'inv-maintenance';
    return null;
}

function getVoucherInventoryCategoryMeta(key) {
    return (VOUCHER_INVENTORY_CATEGORIES || []).find((c) => c.key === key)
        || { key: 'other', label: 'Other', detail: 'Unclassified store items' };
}

function getActiveInventoryCategory() {
    const active = document.querySelector('.voucher-inv-tab.active');
    return active?.dataset.invTab || (VOUCHER_INVENTORY_CATEGORIES[0]?.key) || 'consumables-toners';
}

function getItemOpening(itemId) {
    const inv = ensureStoresInventory();
    return Number(inv.openings[itemId]) || 0;
}

function getItemStockSummary(itemId) {
    const opening = getItemOpening(itemId);
    const txns = ensureStoresInventory().transactions.filter((t) => t.itemId === itemId);
    let received = 0;
    let issued = 0;
    txns.forEach((t) => {
        const qty = Number(t.qty) || 0;
        if (t.type === 'receipt') received += qty;
        else if (t.type === 'issue') issued += qty;
    });
    const catalog = typeof getCatalogItemById === 'function' ? getCatalogItemById(itemId) : null;
    return {
        itemId,
        item: catalog?.name || txns[0]?.item || itemId,
        category: catalog?.category || txns[0]?.category || '',
        gl: catalog?.gl || txns[0]?.gl || '',
        opening,
        received,
        issued,
        onHand: opening + received - issued,
        transactions: txns
    };
}

function getCategoryStockSummary(categoryKey) {
    const catalogItems = typeof getCatalogItemsForCategory === 'function'
        ? getCatalogItemsForCategory(categoryKey)
        : [];
    const inv = ensureStoresInventory();
    const itemIds = new Set(catalogItems.map((i) => i.id));
    const ledger = typeof getInventoryLedgerByKey === 'function' ? getInventoryLedgerByKey(categoryKey) : null;
    const sourceKeys = ledger?.sourceKeys || [];
    const categoryAliases = new Set([categoryKey, ...sourceKeys]);

    // Include legacy / ad-hoc items that only exist in openings or transactions
    Object.keys(inv.openings || {}).forEach((id) => {
        if ([...categoryAliases].some((k) => String(id).startsWith(`${k}__`))) itemIds.add(id);
    });
    (inv.transactions || []).forEach((t) => {
        if (categoryAliases.has(t.category) && t.itemId) itemIds.add(t.itemId);
    });

    let opening = 0;
    let received = 0;
    let issued = 0;
    const itemSummaries = [];
    const transactions = (inv.transactions || []).filter((t) => categoryAliases.has(t.category));

    itemIds.forEach((id) => {
        const row = getItemStockSummary(id);
        opening += row.opening;
        received += row.received;
        issued += row.issued;
        itemSummaries.push(row);
    });

    // Legacy category-level opening (pre-catalog)
    if (!itemIds.size) {
        opening += Number(inv.openings[categoryKey]) || 0;
        sourceKeys.forEach((k) => {
            opening += Number(inv.openings[k]) || 0;
        });
    }

    itemSummaries.sort((a, b) => String(a.item).localeCompare(String(b.item)));

    return {
        opening,
        received,
        issued,
        onHand: opening + received - issued,
        transactions,
        items: itemSummaries
    };
}

function getAllCategoryStockSummaries() {
    const map = {};
    (VOUCHER_INVENTORY_CATEGORIES || []).forEach((cat) => {
        map[cat.key] = getCategoryStockSummary(cat.key);
    });
    return map;
}

function getTrackedItemIds() {
    const inv = ensureStoresInventory();
    const ids = new Set();
    Object.keys(inv.openings || {}).forEach((id) => {
        if (id.includes('__')) ids.add(id);
    });
    (inv.transactions || []).forEach((t) => {
        if (t.itemId) ids.add(t.itemId);
    });
    return [...ids];
}

function getStoresItemDepletionAlerts() {
    const alerts = [];
    getTrackedItemIds().forEach((itemId) => {
        const row = getItemStockSummary(itemId);
        if (row.onHand < 0) {
            alerts.push({
                type: 'danger',
                target: 'voucher-module',
                text: `STOCK OVER-ISSUED: ${row.item} is short by ${Math.abs(row.onHand)}. Reconcile immediately.`
            });
        } else if (row.onHand === 0 && (row.opening > 0 || row.received > 0 || row.issued > 0)) {
            alerts.push({
                type: 'danger',
                target: 'voucher-module',
                text: `STOCK DEPLETED: ${row.item} on hand is 0. Restock or stop further issues.`
            });
        } else if (row.onHand > 0) {
            const base = row.opening + row.received;
            if (base > 0 && row.onHand / base <= 0.2) {
                alerts.push({
                    type: 'warning',
                    target: 'voucher-module',
                    text: `LOW STOCK: ${row.item} has only ${row.onHand} on hand.`
                });
            }
        }
    });

    const session = ensureStoresInventory().daySession;
    if (!session) {
        alerts.push({
            type: 'warning',
            target: 'voucher-module',
            text: 'Day start not recorded. Tap Start of Day to lock opening stock balances.'
        });
    } else if (session.date !== todayIsoDate() && !session.endedAt) {
        alerts.push({
            type: 'warning',
            target: 'voucher-module',
            text: `Previous store day (${session.date}) was not closed. Run Day End Reconcile.`
        });
    }

    return alerts;
}

function postStockTransaction(payload) {
    if (typeof requireEditAccess === 'function' && !requireEditAccess()) return null;

    const type = payload.type === 'receipt' ? 'receipt' : 'issue';
    let catalogItem = payload.itemId && typeof getCatalogItemById === 'function'
        ? getCatalogItemById(payload.itemId)
        : null;
    let itemId = catalogItem?.id || payload.itemId || '';
    let itemName = (catalogItem?.name || payload.item || '').trim();
    let category = catalogItem?.category || payload.category || 'inv-toner';
    let gl = catalogItem?.gl || payload.gl || '';
    const qty = Number(payload.qty) || 0;
    const silent = !!payload.silent;

    if (qty <= 0) {
        if (!silent) showToast('Enter a quantity greater than zero.', 'error');
        return null;
    }
    if (!itemName) {
        if (!silent) showToast('Select a catalog item or enter an item name.', 'error');
        return null;
    }

    // Allow ad-hoc / procurement designations when not in catalog
    if (!itemId && payload.allowAdhoc) {
        if (typeof resolveCatalogOrAdhocItem === 'function') {
            const resolved = resolveCatalogOrAdhocItem(itemName, category);
            itemId = resolved.id;
            itemName = resolved.name;
            category = resolved.category || category;
            gl = resolved.gl || gl;
            catalogItem = resolved.catalog ? resolved : catalogItem;
        } else {
            const slug = itemName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'item';
            itemId = `adhoc__${category}__${slug}`;
        }
    }

    if (!itemId) {
        if (!silent) showToast('Select an item from the IT Directorate catalog.', 'error');
        return null;
    }

    // Idempotent skip if same source+ref+item+type already posted
    if (payload.sourceRef && payload.source) {
        const dup = ensureStoresInventory().transactions.find((t) => (
            t.source === payload.source &&
            t.sourceRef === payload.sourceRef &&
            t.itemId === itemId &&
            t.type === type &&
            Number(t.qty) === qty
        ));
        if (dup) return dup;
    }

    const summary = getItemStockSummary(itemId);
    if (type === 'issue' && qty > summary.onHand) {
        if (!silent) showToast(`Cannot issue ${qty}. Only ${summary.onHand} of "${itemName}" on hand.`, 'error');
        return null;
    }

    const inv = ensureStoresInventory();
    const txn = {
        id: `stk-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        date: payload.date || todayIsoDate(),
        type,
        itemId,
        category,
        item: itemName,
        description: (payload.description || '').trim(),
        qty,
        uom: (payload.uom || 'EA').trim() || 'EA',
        gl,
        voucherNo: (payload.voucherNo || '').trim(),
        party: (payload.party || '').trim(),
        source: (payload.source || 'manual').trim(),
        sourceRef: (payload.sourceRef || '').trim(),
        dpRef: (payload.dpRef || '').trim(),
        poNumber: (payload.poNumber || '').trim(),
        deliveryNoteRef: (payload.deliveryNoteRef || '').trim(),
        by: currentUser?.name || currentUser?.username || 'Storeman',
        createdAt: new Date().toISOString()
    };
    inv.transactions.push(txn);
    saveState();

    const after = getItemStockSummary(itemId);
    if (!silent) {
        if (type === 'receipt') {
            showToast(`Received ${qty} × ${itemName}. On hand: ${after.onHand}.`);
        } else {
            showToast(`Issued ${qty} × ${itemName}. On hand: ${after.onHand}.`);
            if (after.onHand <= 0) {
                showToast(`ALERT: ${itemName} stock is depleted.`, 'error');
            }
        }
    }

    if (typeof renderVoucherInventoryTables === 'function') renderVoucherInventoryTables();
    if (typeof updateSystemAlerts === 'function') updateSystemAlerts();
    if (typeof updateDashboard === 'function') updateDashboard();
    return txn;
}

function startStoreDay() {
    if (typeof requireEditAccess === 'function' && !requireEditAccess()) return;
    const inv = ensureStoresInventory();
    const today = todayIsoDate();

    if (inv.daySession && inv.daySession.date === today && !inv.daySession.endedAt) {
        showToast('Store day already started for today.', 'info');
        return;
    }

    if (inv.daySession && !inv.daySession.endedAt) {
        showToast(`Close the open day (${inv.daySession.date}) with Day End Reconcile first.`, 'error');
        return;
    }

    openStartOfDayModal();
}

function getStockModalDate() {
    return document.getElementById('stockTxnModalDate')?.value || todayIsoDate();
}

function setStockModalDate(value) {
    const el = document.getElementById('stockTxnModalDate');
    if (el) el.value = value || todayIsoDate();
}

function resetStockModalWindowState() {
    const modal = document.getElementById('stockTxnModal');
    const dialog = document.getElementById('stockTxnModalDialog');
    const maxBtn = document.getElementById('stockTxnModalMaximize');
    const minBar = document.getElementById('stockTxnMinimizedBar');
    if (!modal || !dialog) return;

    modal.classList.remove('is-maximized', 'is-minimized');
    dialog.style.width = '';
    dialog.style.height = '';
    if (minBar) minBar.hidden = true;
    if (maxBtn) {
        maxBtn.textContent = '▢';
        maxBtn.title = 'Maximize';
        maxBtn.setAttribute('aria-label', 'Maximize');
    }
}

function minimizeStockTxnModal() {
    const modal = document.getElementById('stockTxnModal');
    const title = document.getElementById('stockTxnModalTitle')?.textContent || 'Stock form';
    const label = document.getElementById('stockTxnMinimizedLabel');
    const minBar = document.getElementById('stockTxnMinimizedBar');
    if (!modal) return;
    modal.classList.remove('is-maximized');
    modal.classList.add('is-minimized');
    if (label) label.textContent = `${title} · ${getStockModalDate()}`;
    if (minBar) minBar.hidden = false;
}

function restoreStockTxnModal() {
    const modal = document.getElementById('stockTxnModal');
    const minBar = document.getElementById('stockTxnMinimizedBar');
    if (!modal) return;
    modal.classList.remove('is-minimized');
    if (minBar) minBar.hidden = true;
}

function toggleMaximizeStockTxnModal() {
    const modal = document.getElementById('stockTxnModal');
    const dialog = document.getElementById('stockTxnModalDialog');
    const maxBtn = document.getElementById('stockTxnModalMaximize');
    if (!modal || !dialog) return;

    const willMaximize = !modal.classList.contains('is-maximized');
    modal.classList.remove('is-minimized');
    const minBar = document.getElementById('stockTxnMinimizedBar');
    if (minBar) minBar.hidden = true;

    if (willMaximize) {
        dialog.style.width = '';
        dialog.style.height = '';
        modal.classList.add('is-maximized');
        if (maxBtn) {
            maxBtn.textContent = '❐';
            maxBtn.title = 'Restore size';
            maxBtn.setAttribute('aria-label', 'Restore size');
        }
    } else {
        modal.classList.remove('is-maximized');
        if (maxBtn) {
            maxBtn.textContent = '▢';
            maxBtn.title = 'Maximize';
            maxBtn.setAttribute('aria-label', 'Maximize');
        }
    }
}

function buildCatalogItemOptionsHtml(categoryKey, selectedId) {
    const items = typeof getCatalogItemsForCategory === 'function'
        ? getCatalogItemsForCategory(categoryKey)
        : [];
    if (typeof buildCatalogItemSelectOptionsHtml === 'function') {
        return buildCatalogItemSelectOptionsHtml(items, selectedId, categoryKey);
    }
    const sorted = [...items].sort((a, b) =>
        String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' })
    );
    const opts = ['<option value="">— Select catalog item —</option>']
        .concat(sorted.map((item) => {
            const sel = item.id === selectedId ? ' selected' : '';
            return `<option value="${invHtmlEscape(item.id)}"${sel}>${invHtmlEscape(item.name)}</option>`;
        }));
    return opts.join('');
}

function fillCatalogItemSelect(selectEl, categoryKey, selectedId) {
    if (!selectEl) return;
    selectEl.innerHTML = buildCatalogItemOptionsHtml(categoryKey, selectedId);
}

function openStartOfDayModal() {
    const title = document.getElementById('stockTxnModalTitle');
    const body = document.getElementById('stockTxnModalBody');
    const confirmBtn = document.getElementById('stockTxnModalConfirm');
    if (!title || !body || !confirmBtn) return;

    const category = getActiveInventoryCategory();
    title.textContent = 'Start of Day — Opening Stocks';
    confirmBtn.textContent = 'Lock Opening Stocks';
    confirmBtn.dataset.mode = 'day-start';
    setStockModalDate(todayIsoDate());

    body.innerHTML = `
        <p class="modal-help">Enter opening counts for IT Directorate catalog items. Use the category and search to find items (toners, spares, ICT equipment, software, etc.).</p>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">Catalog Category</label>
                <select class="form-control" id="dayStartCategory">${buildCategoryOptionsHtml(category)}</select>
            </div>
            <div class="form-col">
                <label class="form-label">Search Items</label>
                <input type="search" class="form-control" id="dayStartSearch" data-search-history="1" data-search-history-key="day-start-catalog" placeholder="e.g. CE505A / laptop / Cisco" autocomplete="off">
            </div>
        </div>
        <div class="form-table-wrapper">
            <table class="overview-table">
                <thead>
                    <tr>
                        <th>Catalog Item</th>
                        <th>Current System</th>
                        <th>Opening Count</th>
                    </tr>
                </thead>
                <tbody id="dayStartItemsBody"></tbody>
            </table>
        </div>
    `;

    const refreshRows = () => {
        const cat = document.getElementById('dayStartCategory')?.value || category;
        const q = (document.getElementById('dayStartSearch')?.value || '').trim().toLowerCase();
        const items = (typeof getCatalogItemsForCategory === 'function' ? getCatalogItemsForCategory(cat) : [])
            .filter((item) => !q || item.name.toLowerCase().includes(q));
        const tbody = document.getElementById('dayStartItemsBody');
        if (!tbody) return;
        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="3">No catalog items match this filter.</td></tr>';
            return;
        }
        tbody.innerHTML = items.map((item) => {
            const sys = getItemStockSummary(item.id).onHand;
            return `
                <tr>
                    <td>${invHtmlEscape(item.name)}</td>
                    <td>${sys}</td>
                    <td>
                        <input type="number" class="form-control day-start-opening" data-item-id="${invHtmlEscape(item.id)}" min="0" step="1" value="${sys}">
                    </td>
                </tr>
            `;
        }).join('');
    };

    body.querySelector('#dayStartCategory')?.addEventListener('change', refreshRows);
    body.querySelector('#dayStartSearch')?.addEventListener('input', refreshRows);
    if (typeof bindSearchHistory === 'function') {
        const searchEl = document.getElementById('dayStartSearch');
        if (searchEl) {
            bindSearchHistory(searchEl);
            searchEl.addEventListener('search-history-commit', refreshRows);
            searchEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (typeof rememberSearchTerm === 'function') rememberSearchTerm(searchEl, searchEl.value);
                    refreshRows();
                }
            });
        }
    }
    refreshRows();
    openStockTxnModal();
}

function completeStartOfDay() {
    const inv = ensureStoresInventory();
    const dayDate = getStockModalDate();

    // Fold current on-hand into openings for all tracked items, then apply modal overrides
    const snapshot = { ...(inv.openings || {}) };
    getTrackedItemIds().forEach((itemId) => {
        snapshot[itemId] = getItemStockSummary(itemId).onHand;
    });
    document.querySelectorAll('.day-start-opening[data-item-id]').forEach((input) => {
        const itemId = input.dataset.itemId;
        const raw = Number(input.value);
        if (!itemId) return;
        snapshot[itemId] = Number.isFinite(raw) && raw >= 0 ? raw : (snapshot[itemId] || 0);
    });

    if (inv.transactions.length) {
        inv.dayHistory = [...(inv.dayHistory || []), {
            date: dayDate,
            note: 'Carry-forward before Start of Day',
            transactionsSnapshot: [...inv.transactions],
            closedAt: new Date().toISOString()
        }].slice(-60);
    }
    inv.transactions = [];
    inv.openings = snapshot;

    inv.daySession = {
        date: dayDate,
        startedAt: new Date().toISOString(),
        startedBy: currentUser?.name || currentUser?.username || 'Storeman',
        openingSnapshot: { ...snapshot },
        endedAt: null,
        endedBy: null,
        physicalCounts: null,
        systemClosing: null,
        variances: null
    };

    saveState();
    closeStockTxnModal();
    renderVoucherInventoryTables();
    if (typeof updateSystemAlerts === 'function') updateSystemAlerts();
    showToast(`Start of Day recorded. Opening stocks locked for ${dayDate}.`);
}

function openDayEndReconcileModal() {
    if (typeof requireEditAccess === 'function' && !requireEditAccess()) return;
    const inv = ensureStoresInventory();
    if (!inv.daySession || inv.daySession.endedAt) {
        showToast('Start of Day first, then reconcile at day end.', 'error');
        return;
    }

    const body = document.getElementById('stockTxnModalBody');
    const title = document.getElementById('stockTxnModalTitle');
    const confirmBtn = document.getElementById('stockTxnModalConfirm');
    if (!body || !title || !confirmBtn) return;

    const category = getActiveInventoryCategory();
    title.textContent = 'Day End Stock Reconciliation';
    confirmBtn.textContent = 'Complete Day End';
    confirmBtn.dataset.mode = 'day-end';
    setStockModalDate(inv.daySession.date || todayIsoDate());
    body.innerHTML = `
        <p class="modal-help">Enter physical counts for catalog items. Variance = Physical − System. Completing day end carries physical stock forward as tomorrow’s opening.</p>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">Catalog Category</label>
                <select class="form-control" id="dayEndCategory">${buildCategoryOptionsHtml(category)}</select>
            </div>
            <div class="form-col">
                <label class="form-label">Search Items</label>
                <input type="search" class="form-control" id="dayEndSearch" data-search-history="1" data-search-history-key="day-end-catalog" placeholder="Filter items..." autocomplete="off">
            </div>
        </div>
        <label class="form-label" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
            <input type="checkbox" id="dayEndShowAll"> Show all catalog items in category (not only items with stock)
        </label>
        <div class="form-table-wrapper">
            <table class="overview-table">
                <thead>
                    <tr>
                        <th>Catalog Item</th>
                        <th>System On Hand</th>
                        <th>Physical Count</th>
                        <th>Variance</th>
                    </tr>
                </thead>
                <tbody id="dayEndItemsBody"></tbody>
            </table>
        </div>
    `;

    const refreshRows = () => {
        const cat = document.getElementById('dayEndCategory')?.value || category;
        const q = (document.getElementById('dayEndSearch')?.value || '').trim().toLowerCase();
        const showAll = !!document.getElementById('dayEndShowAll')?.checked;
        let items = typeof getCatalogItemsForCategory === 'function' ? getCatalogItemsForCategory(cat) : [];
        if (!showAll) {
            items = items.filter((item) => {
                const s = getItemStockSummary(item.id);
                return s.opening || s.received || s.issued || s.onHand;
            });
        }
        items = items.filter((item) => !q || item.name.toLowerCase().includes(q));
        const tbody = document.getElementById('dayEndItemsBody');
        if (!tbody) return;
        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="4">No items to reconcile in this view. Tick “Show all” or receive stock first.</td></tr>';
            return;
        }
        tbody.innerHTML = items.map((item) => {
            const sys = getItemStockSummary(item.id).onHand;
            return `
                <tr>
                    <td>${invHtmlEscape(item.name)}</td>
                    <td><strong data-sys-close="${invHtmlEscape(item.id)}">${sys}</strong></td>
                    <td>
                        <input type="number" class="form-control day-end-count" data-item-id="${invHtmlEscape(item.id)}" min="0" step="1" value="${sys}">
                    </td>
                    <td class="day-end-variance" data-var-item="${invHtmlEscape(item.id)}">0</td>
                </tr>
            `;
        }).join('');

        tbody.querySelectorAll('.day-end-count').forEach((input) => {
            input.addEventListener('input', () => {
                const id = input.dataset.itemId;
                const sys = Number(tbody.querySelector(`[data-sys-close="${id}"]`)?.textContent) || 0;
                const physical = Number(input.value) || 0;
                const varEl = tbody.querySelector(`[data-var-item="${id}"]`);
                if (varEl) {
                    const v = physical - sys;
                    varEl.textContent = (v >= 0 ? '+' : '') + v;
                    varEl.classList.toggle('var-negative', v < 0);
                    varEl.classList.toggle('var-positive', v > 0);
                }
            });
        });
    };

    body.querySelector('#dayEndCategory')?.addEventListener('change', refreshRows);
    body.querySelector('#dayEndSearch')?.addEventListener('input', refreshRows);
    body.querySelector('#dayEndShowAll')?.addEventListener('change', refreshRows);
    if (typeof bindSearchHistory === 'function') {
        const searchEl = document.getElementById('dayEndSearch');
        if (searchEl) {
            bindSearchHistory(searchEl);
            searchEl.addEventListener('search-history-commit', refreshRows);
            searchEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (typeof rememberSearchTerm === 'function') rememberSearchTerm(searchEl, searchEl.value);
                    refreshRows();
                }
            });
        }
    }
    refreshRows();
    openStockTxnModal();
}

function completeDayEndReconcile() {
    const inv = ensureStoresInventory();
    if (!inv.daySession || inv.daySession.endedAt) {
        showToast('No open store day to close.', 'error');
        return;
    }

    const physicalCounts = {};
    const systemClosing = {};
    const variances = {};
    let hasShort = false;

    // Fold all tracked items to system on-hand first
    getTrackedItemIds().forEach((itemId) => {
        const sys = getItemStockSummary(itemId).onHand;
        systemClosing[itemId] = sys;
        physicalCounts[itemId] = sys;
        variances[itemId] = 0;
        inv.openings[itemId] = sys;
    });

    document.querySelectorAll('.day-end-count[data-item-id]').forEach((input) => {
        const itemId = input.dataset.itemId;
        const sys = getItemStockSummary(itemId).onHand;
        const physical = Number(input.value);
        const count = Number.isFinite(physical) ? physical : sys;
        physicalCounts[itemId] = count;
        systemClosing[itemId] = sys;
        variances[itemId] = count - sys;
        if (count < sys) hasShort = true;
        inv.openings[itemId] = count;
    });

    const closedSession = {
        ...inv.daySession,
        endedAt: new Date().toISOString(),
        endedBy: currentUser?.name || currentUser?.username || 'Storeman',
        physicalCounts,
        systemClosing,
        variances,
        transactionsSnapshot: [...inv.transactions]
    };
    inv.dayHistory = [...(inv.dayHistory || []), closedSession].slice(-60);
    inv.daySession = null;
    inv.transactions = [];

    saveState();
    closeStockTxnModal();
    renderVoucherInventoryTables();
    if (typeof updateSystemAlerts === 'function') updateSystemAlerts();
    if (typeof updateDashboard === 'function') updateDashboard();

    showToast('Day end reconciliation complete. Opening stocks updated for next day.');
    if (hasShort) {
        showToast('ALERT: One or more items counted below system stock.', 'error');
    }
}

function buildCategoryOptionsHtml(selected) {
    return (VOUCHER_INVENTORY_CATEGORIES || []).map((cat) => {
        const sel = cat.key === selected ? ' selected' : '';
        return `<option value="${cat.key}"${sel}>${invHtmlEscape(cat.label)}</option>`;
    }).join('');
}

function buildGlOptionsHtml(selected) {
    const value = selected || '2200600002';
    return Object.entries(GL_ACCOUNTS).map(([code, info]) => {
        const sel = code === value ? ' selected' : '';
        return `<option value="${code}"${sel}>${code} - ${invHtmlEscape(info.name)}</option>`;
    }).join('');
}

function openReceiveIssueModal(type) {
    if (typeof requireEditAccess === 'function' && !requireEditAccess()) return;

    const isReceipt = type === 'receipt';
    const title = document.getElementById('stockTxnModalTitle');
    const body = document.getElementById('stockTxnModalBody');
    const confirmBtn = document.getElementById('stockTxnModalConfirm');
    if (!title || !body || !confirmBtn) return;

    const category = getActiveInventoryCategory();
    const section = (VOUCHER_INVENTORY_CATEGORIES || []).find((c) => c.key === category);
    const defaultGl = section?.gl || '2200600002';

    title.textContent = isReceipt ? 'Receive Stock (Increase Inventory)' : 'Issue Stock (Deplete Inventory)';
    confirmBtn.textContent = isReceipt ? 'Confirm Receive' : 'Confirm Issue';
    confirmBtn.dataset.mode = isReceipt ? 'receipt' : 'issue';
    setStockModalDate(todayIsoDate());

    body.innerHTML = `
        <p class="modal-help">
            ${isReceipt
                ? 'Select an IT Directorate catalog item to receive from a supplier. This increases that item’s stock.'
                : 'Select an IT Directorate catalog item to issue to a user. This depletes that item’s stock.'}
            Missing an item? Use <strong>Add new catalog item</strong> below — it is saved for future receive/issue.
        </p>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">Catalog Category</label>
                <select class="form-control" id="stockTxnCategory">${buildCategoryOptionsHtml(category)}</select>
            </div>
            <div class="form-col">
                <label class="form-label">Catalog Item</label>
                <select class="form-control" id="stockTxnItemId">${buildCatalogItemOptionsHtml(category)}</select>
            </div>
        </div>
        <div class="stock-add-catalog-box">
            <button type="button" class="btn btn-ghost btn-sm" id="stockTxnToggleAddItem">＋ Add new catalog item</button>
            <div class="stock-add-catalog-panel" id="stockTxnAddItemPanel" hidden>
                <label class="form-label" for="stockTxnNewItemName">New item name</label>
                <div class="form-row">
                    <div class="form-col" style="flex:1.6;">
                        <input type="text" class="form-control" id="stockTxnNewItemName"
                            placeholder="e.g. Cursor AI · Claude · SQL Server · Visual Studio"
                            autocomplete="off">
                    </div>
                    <div class="form-col" id="stockTxnNewItemNatureWrap" style="flex:1.2;" hidden>
                        <label class="form-label" for="stockTxnNewItemNature">Nature of use</label>
                        <select class="form-control" id="stockTxnNewItemNature">
                            ${typeof buildSoftwareUseNatureOptionsHtml === 'function'
                                ? buildSoftwareUseNatureOptionsHtml('other')
                                : '<option value="other">Other Software</option>'}
                        </select>
                    </div>
                    <div class="form-col" style="flex:0 0 auto; display:flex; align-items:flex-end; gap:6px;">
                        <button type="button" class="btn btn-primary btn-sm" id="stockTxnSaveNewItem">Save to category</button>
                    </div>
                </div>
                <p class="modal-help" style="margin:6px 0 0;">Saved under the selected Catalog Category (Softwares are grouped by nature of use) and available immediately in the item list.</p>
            </div>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">Search Catalog</label>
                <input type="search" class="form-control" id="stockTxnItemSearch" data-search-history="1" data-search-history-key="stock-txn-catalog" placeholder="Type to filter items..." autocomplete="off">
            </div>
            <div class="form-col">
                <label class="form-label">Quantity</label>
                <input type="number" class="form-control" id="stockTxnQty" min="1" step="1" value="1">
            </div>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">Description / Remarks</label>
                <input type="text" class="form-control" id="stockTxnDesc" placeholder="Optional details">
            </div>
            <div class="form-col">
                <label class="form-label">Unit of Measure</label>
                <input type="text" class="form-control" id="stockTxnUom" value="EA">
            </div>
        </div>
        <div class="form-row">
            <div class="form-col">
                <label class="form-label">GL Account</label>
                <select class="form-control" id="stockTxnGl">${buildGlOptionsHtml(defaultGl)}</select>
            </div>
            <div class="form-col">
                <label class="form-label">${isReceipt ? 'RV No.' : 'IV No.'}</label>
                <input type="text" class="form-control" id="stockTxnVoucherNo">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">${isReceipt ? 'Received From / Supplier' : 'Issued To'}</label>
            <input type="text" class="form-control" id="stockTxnParty" placeholder="${isReceipt ? 'Supplier / consignor' : 'Unit / person'}">
        </div>
        <div class="stock-onhand-hint" id="stockTxnOnHandHint">Select a catalog item to see on-hand quantity.</div>
    `;

    const refreshHint = () => {
        const itemId = document.getElementById('stockTxnItemId')?.value;
        const hint = document.getElementById('stockTxnOnHandHint');
        if (!hint) return;
        if (!itemId) {
            hint.textContent = 'Select a catalog item to see on-hand quantity.';
            return;
        }
        const sum = getItemStockSummary(itemId);
        hint.innerHTML = `On hand for <strong>${invHtmlEscape(sum.item)}</strong>: <strong>${sum.onHand}</strong>`;
    };

    const refillItems = (preferSelectId) => {
        const cat = document.getElementById('stockTxnCategory')?.value || category;
        const q = (document.getElementById('stockTxnItemSearch')?.value || '').trim().toLowerCase();
        const select = document.getElementById('stockTxnItemId');
        if (!select) return;
        let items = typeof getCatalogItemsForCategory === 'function' ? getCatalogItemsForCategory(cat) : [];
        if (q) items = items.filter((item) => item.name.toLowerCase().includes(q));
        const prev = preferSelectId || select.value;
        if (typeof buildCatalogItemSelectOptionsHtml === 'function') {
            select.innerHTML = buildCatalogItemSelectOptionsHtml(items, prev, cat);
        } else {
            select.innerHTML = ['<option value="">— Select catalog item —</option>']
                .concat(items.map((item) => {
                    const mark = item.custom ? ' ★' : '';
                    return `<option value="${invHtmlEscape(item.id)}">${invHtmlEscape(item.name)}${mark}</option>`;
                }))
                .join('');
            if (prev && [...select.options].some((o) => o.value === prev)) select.value = prev;
        }
        const natureWrap = document.getElementById('stockTxnNewItemNatureWrap');
        if (natureWrap) {
            natureWrap.hidden = !(typeof isSoftwareCatalogCategory === 'function' && isSoftwareCatalogCategory(cat));
        }
        const meta = (VOUCHER_INVENTORY_CATEGORIES || []).find((c) => c.key === cat);
        const glEl = document.getElementById('stockTxnGl');
        if (glEl && meta?.gl) glEl.value = meta.gl;
        refreshHint();
    };

    const suggestNatureFromName = () => {
        const name = document.getElementById('stockTxnNewItemName')?.value || '';
        const natureEl = document.getElementById('stockTxnNewItemNature');
        if (!natureEl || typeof classifySoftwareUseNature !== 'function') return;
        natureEl.value = classifySoftwareUseNature(name);
    };

    const saveNewCatalogItem = () => {
        if (typeof requireEditAccess === 'function' && !requireEditAccess()) return;
        const cat = document.getElementById('stockTxnCategory')?.value || category;
        const name = document.getElementById('stockTxnNewItemName')?.value || '';
        const gl = document.getElementById('stockTxnGl')?.value || '';
        const useNature = document.getElementById('stockTxnNewItemNature')?.value || '';
        if (typeof addCustomCatalogItem !== 'function') {
            showToast('Catalog add is not available.', 'error');
            return;
        }
        const created = addCustomCatalogItem({ name, category: cat, gl, useNature });
        if (!created) return;
        const search = document.getElementById('stockTxnItemSearch');
        if (search) search.value = '';
        const nameEl = document.getElementById('stockTxnNewItemName');
        if (nameEl) nameEl.value = '';
        const panel = document.getElementById('stockTxnAddItemPanel');
        if (panel) panel.hidden = true;
        refillItems(created.id);
        document.getElementById('stockTxnQty')?.focus();
    };

    body.querySelector('#stockTxnCategory')?.addEventListener('change', () => refillItems());
    body.querySelector('#stockTxnItemSearch')?.addEventListener('input', () => refillItems());
    body.querySelector('#stockTxnItemId')?.addEventListener('change', refreshHint);
    body.querySelector('#stockTxnToggleAddItem')?.addEventListener('click', () => {
        const panel = document.getElementById('stockTxnAddItemPanel');
        if (!panel) return;
        panel.hidden = !panel.hidden;
        if (!panel.hidden) document.getElementById('stockTxnNewItemName')?.focus();
    });
    body.querySelector('#stockTxnSaveNewItem')?.addEventListener('click', saveNewCatalogItem);
    body.querySelector('#stockTxnNewItemName')?.addEventListener('input', suggestNatureFromName);
    body.querySelector('#stockTxnNewItemName')?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            saveNewCatalogItem();
        }
    });
    refillItems();
    if (typeof bindSearchHistory === 'function') {
        const searchEl = document.getElementById('stockTxnItemSearch');
        if (searchEl) {
            bindSearchHistory(searchEl);
            searchEl.addEventListener('search-history-commit', () => refillItems());
            searchEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (typeof rememberSearchTerm === 'function') rememberSearchTerm(searchEl, searchEl.value);
                    refillItems();
                }
            });
        }
    }

    openStockTxnModal();
    setTimeout(() => document.getElementById('stockTxnItemSearch')?.focus(), 50);
}

function confirmStockTxnModal() {
    const confirmBtn = document.getElementById('stockTxnModalConfirm');
    const mode = confirmBtn?.dataset.mode;
    if (mode === 'day-start') {
        completeStartOfDay();
        return;
    }
    if (mode === 'day-end') {
        completeDayEndReconcile();
        return;
    }
    if (mode === 'add-inventory-ledger') {
        if (typeof confirmAddInventoryLedgerFromModal === 'function') confirmAddInventoryLedgerFromModal();
        return;
    }
    if (mode !== 'receipt' && mode !== 'issue') return;

    const itemId = document.getElementById('stockTxnItemId')?.value || '';
    const catalogItem = typeof getCatalogItemById === 'function' ? getCatalogItemById(itemId) : null;
    const payload = {
        type: mode,
        date: getStockModalDate(),
        itemId,
        category: document.getElementById('stockTxnCategory')?.value || catalogItem?.category || '',
        item: catalogItem?.name || '',
        description: document.getElementById('stockTxnDesc')?.value || '',
        qty: document.getElementById('stockTxnQty')?.value,
        uom: document.getElementById('stockTxnUom')?.value || 'EA',
        gl: document.getElementById('stockTxnGl')?.value || catalogItem?.gl || '',
        voucherNo: document.getElementById('stockTxnVoucherNo')?.value || '',
        party: document.getElementById('stockTxnParty')?.value || ''
    };

    const txn = postStockTransaction(payload);
    if (txn) closeStockTxnModal();
}

function openStockTxnModal() {
    const modal = document.getElementById('stockTxnModal');
    if (!modal) return;
    resetStockModalWindowState();
    if (!document.getElementById('stockTxnModalDate')?.value) {
        setStockModalDate(todayIsoDate());
    }
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
}

function closeStockTxnModal() {
    const modal = document.getElementById('stockTxnModal');
    if (!modal) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    resetStockModalWindowState();
}

function syncOpeningInputsFromState() {
    document.querySelectorAll('.voucher-inv-opening').forEach((input) => {
        const key = input.dataset.invCat;
        if (key == null) return;
        input.value = getCategoryStockSummary(key).opening;
    });
}

function updateDaySessionBanner() {
    const el = document.getElementById('storeDaySessionBanner');
    if (!el) return;
    const session = ensureStoresInventory().daySession;
    if (!session) {
        el.className = 'store-day-banner store-day-banner-warn';
        el.innerHTML = '<strong>Day not started.</strong> Tap <em>Start of Day</em> to lock opening stocks before receiving or issuing.';
        return;
    }
    if (session.endedAt) {
        el.className = 'store-day-banner';
        el.textContent = 'No active store day.';
        return;
    }
    el.className = 'store-day-banner store-day-banner-ok';
    el.innerHTML = `<strong>Store day open:</strong> ${invHtmlEscape(session.date)} · started by ${invHtmlEscape(session.startedBy || '—')} · openings locked at start of day`;
}

function buildVoucherInventorySection() {
    const host = document.getElementById('voucherInventorySection');
    if (!host) return;
    if (host.dataset.built === '1') {
        const tabCount = host.querySelectorAll('.voucher-inv-tab').length;
        if (tabCount === (VOUCHER_INVENTORY_CATEGORIES || []).length) return;
        host.dataset.built = '0';
        host.innerHTML = '';
    }

    const tabs = VOUCHER_INVENTORY_CATEGORIES.map((cat, i) => `
        <button type="button" class="voucher-inv-tab${i === 0 ? ' active' : ''}" data-inv-tab="${cat.key}" title="${invHtmlEscape(cat.fullLabel || cat.label)}">
            ${invHtmlEscape(cat.label)}
            <span class="voucher-inv-tab-count" data-inv-count="${cat.key}">0</span>
        </button>
    `).join('');

    const panels = VOUCHER_INVENTORY_CATEGORIES.map((cat, i) => `
        <div class="voucher-inv-panel${i === 0 ? ' active' : ''}" data-inv-panel="${cat.key}" ${i === 0 ? '' : 'hidden'}>
            <div class="voucher-inv-panel-head">
                <div>
                    <h4>${invHtmlEscape(cat.fullLabel || cat.label)}</h4>
                    <p>${invHtmlEscape(cat.detail)}${cat.gl ? ` · Charge GL ${invHtmlEscape(cat.gl)} (procurement only)` : ''}</p>
                </div>
                <div class="voucher-inv-opening-wrap">
                    <label>Category Opening Total</label>
                    <input type="number" class="form-control voucher-inv-opening" data-inv-cat="${cat.key}" min="0" step="1" value="0" readonly title="Sum of item openings">
                </div>
            </div>
            <div class="voucher-inv-metrics">
                <div><span>Received</span><strong class="inv-received" data-inv-received="${cat.key}">0</strong></div>
                <div><span>Issued</span><strong class="inv-issued" data-inv-issued="${cat.key}">0</strong></div>
                <div><span>On Hand</span><strong class="inv-onhand" data-inv-onhand="${cat.key}">0</strong></div>
            </div>

            <h5 class="voucher-inv-subtitle">Item Stock Balances</h5>
            <div class="module-toolbar">
                <input type="search" class="form-control table-search" data-search-target="voucher-inv-items-${cat.key}" placeholder="Search catalog items...">
                <button type="button" class="btn btn-primary btn-sm btn-table-search">Search</button>
                <button type="button" class="btn btn-ghost btn-sm btn-table-search-clear">Clear</button>
            </div>
            <div class="form-table-wrapper">
                <table class="overview-table voucher-inv-table">
                    <thead>
                        <tr>
                            <th>Catalog Item</th>
                            <th>Opening</th>
                            <th>Received</th>
                            <th>Issued</th>
                            <th>On Hand</th>
                        </tr>
                    </thead>
                    <tbody id="voucher-inv-items-${cat.key}" data-inventory-view="1"></tbody>
                </table>
            </div>

            <h5 class="voucher-inv-subtitle">Receive / Issue Movements</h5>
            <div class="module-toolbar">
                <input type="search" class="form-control table-search" data-search-target="voucher-inv-body-${cat.key}" placeholder="Search movements...">
                <button type="button" class="btn btn-primary btn-sm btn-table-search">Search</button>
                <button type="button" class="btn btn-ghost btn-sm btn-table-search-clear">Clear</button>
            </div>
            <div class="form-table-wrapper">
                <table class="overview-table voucher-inv-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Item</th>
                            <th>Description</th>
                            <th>Qty</th>
                            <th>UoM</th>
                            <th>GL</th>
                            <th>RV/IV No.</th>
                            <th>Party</th>
                            <th>By</th>
                        </tr>
                    </thead>
                    <tbody id="voucher-inv-body-${cat.key}" data-inventory-view="1"></tbody>
                </table>
            </div>
        </div>
    `).join('');

    host.innerHTML = `
        <div class="section-heading">
            <div>
                <h3>Stores Inventory Control</h3>
                <p>Standalone inventory ledgers (separate from GL Portfolio) · Form 1033 receive/issue · Start of Day / Day End</p>
            </div>
        </div>

        <div class="store-stock-actions" role="group" aria-label="Stock actions">
            <button type="button" class="btn btn-success" id="btnReceiveStock">＋ Receive</button>
            <button type="button" class="btn btn-danger" id="btnIssueStock">− Issue</button>
            <button type="button" class="btn btn-primary" id="btnStartStoreDay">Start of Day</button>
            <button type="button" class="btn btn-secondary" id="btnDayEndReconcile">Day End Reconcile</button>
            <button type="button" class="btn btn-ghost" id="btnAddInventoryLedger">＋ Add Inventory Ledger</button>
            <button type="button" class="btn btn-secondary btn-generate-report" id="btnInventoryReport" data-report-module="stores-inventory">Generate Inventory Report</button>
            <button type="button" class="btn btn-ghost btn-sm" id="refreshVoucherInventoryBtn">Refresh</button>
        </div>

        <div id="storeDaySessionBanner" class="store-day-banner" aria-live="polite"></div>

        <div class="voucher-inv-tabs" id="voucherInvTabs">${tabs}</div>
        <div class="voucher-inv-panels" id="voucherInvPanels">${panels}</div>
    `;
    host.dataset.built = '1';

    host.querySelectorAll('.voucher-inv-tab').forEach((tab) => {
        tab.addEventListener('click', () => {
            const key = tab.dataset.invTab;
            host.querySelectorAll('.voucher-inv-tab').forEach((t) => t.classList.toggle('active', t === tab));
            host.querySelectorAll('.voucher-inv-panel').forEach((panel) => {
                const on = panel.dataset.invPanel === key;
                panel.classList.toggle('active', on);
                panel.hidden = !on;
            });
        });
    });

    document.getElementById('btnReceiveStock')?.addEventListener('click', () => openReceiveIssueModal('receipt'));
    document.getElementById('btnIssueStock')?.addEventListener('click', () => openReceiveIssueModal('issue'));
    document.getElementById('btnStartStoreDay')?.addEventListener('click', startStoreDay);
    document.getElementById('btnDayEndReconcile')?.addEventListener('click', openDayEndReconcileModal);
    document.getElementById('btnAddInventoryLedger')?.addEventListener('click', () => {
        if (typeof openAddInventoryLedgerModal === 'function') openAddInventoryLedgerModal();
    });
    document.getElementById('refreshVoucherInventoryBtn')?.addEventListener('click', () => {
        renderVoucherInventoryTables();
        showToast('Inventory refreshed.', 'info');
    });

    syncOpeningInputsFromState();
    if (typeof initTableSearch === 'function') initTableSearch();
}

function renderVoucherInventoryTables() {
    ensureStoresInventory();
    buildVoucherInventorySection();
    const host = document.getElementById('voucherInventorySection');
    if (!host) return;

    syncOpeningInputsFromState();
    updateDaySessionBanner();

    VOUCHER_INVENTORY_CATEGORIES.forEach((cat) => {
        const summary = getCategoryStockSummary(cat.key);
        const catalogItems = typeof getCatalogItemsForCategory === 'function'
            ? getCatalogItemsForCategory(cat.key)
            : [];
        const itemRows = catalogItems.map((item) => getItemStockSummary(item.id))
            .filter((row) => row.opening || row.received || row.issued || row.onHand);

        const itemsBody = document.getElementById(`voucher-inv-items-${cat.key}`);
        const tbody = document.getElementById(`voucher-inv-body-${cat.key}`);
        const countEl = host.querySelector(`[data-inv-count="${cat.key}"]`);
        if (countEl) countEl.textContent = String(itemRows.length || summary.transactions.length);

        const onHandEl = host.querySelector(`[data-inv-onhand="${cat.key}"]`);
        if (onHandEl) {
            onHandEl.textContent = String(summary.onHand);
            onHandEl.classList.toggle('stock-depleted', summary.onHand <= 0 && (summary.opening > 0 || summary.received > 0 || summary.issued > 0));
            onHandEl.classList.toggle('stock-overdrawn', summary.onHand < 0);
        }

        if (itemsBody) {
            if (!itemRows.length) {
                itemsBody.innerHTML = `<tr class="empty-inv-row"><td colspan="5">No stock recorded for this catalog yet. Use <strong>Start of Day</strong> or <strong>Receive</strong>.</td></tr>`;
            } else {
                itemsBody.innerHTML = itemRows.map((row) => `
                    <tr>
                        <td>${invHtmlEscape(row.item)}</td>
                        <td>${row.opening}</td>
                        <td class="inv-received">${row.received}</td>
                        <td class="inv-issued">${row.issued}</td>
                        <td><strong class="${row.onHand <= 0 ? 'stock-depleted' : 'inv-onhand'}">${row.onHand}</strong></td>
                    </tr>
                `).join('');
            }
        }

        if (tbody) {
            const rows = summary.transactions;
            if (!rows.length) {
                tbody.innerHTML = `<tr class="empty-inv-row"><td colspan="11">No receive/issue movements yet for ${invHtmlEscape(cat.label)}.</td></tr>`;
            } else {
                tbody.innerHTML = rows.map((txn, idx) => {
                    const isReceipt = txn.type === 'receipt';
                    return `
                        <tr>
                            <td>${idx + 1}</td>
                            <td>${invHtmlEscape(txn.date || '—')}</td>
                            <td><span class="txn-badge ${isReceipt ? 'txn-receipt' : 'txn-issue'}">${isReceipt ? 'Receive' : 'Issue'}</span></td>
                            <td>${invHtmlEscape(txn.item)}</td>
                            <td>${invHtmlEscape(txn.description || '—')}</td>
                            <td>${txn.qty || 0}</td>
                            <td>${invHtmlEscape(txn.uom || 'EA')}</td>
                            <td>${invHtmlEscape(txn.gl || '—')}</td>
                            <td>${invHtmlEscape(txn.voucherNo || '—')}</td>
                            <td>${invHtmlEscape(txn.party || '—')}</td>
                            <td>${invHtmlEscape(txn.by || '—')}</td>
                        </tr>
                    `;
                }).join('');
            }
        }

        const setMetric = (sel, value) => {
            const el = host.querySelector(sel);
            if (el) el.textContent = String(value);
        };
        setMetric(`[data-inv-received="${cat.key}"]`, summary.received);
        setMetric(`[data-inv-issued="${cat.key}"]`, summary.issued);
    });
}

function attachVoucherInventoryRowWatch(tr) {
    if (!tr || tr.dataset.invWatch === '1') return;
    tr.dataset.invWatch = '1';

    const nameInput = tr.querySelector('.voucher-item-name');
    const categorySelect = tr.querySelector('.voucher-item-category');
    nameInput?.addEventListener('blur', () => {
        if (!categorySelect) return;
        if (categorySelect.value && categorySelect.value !== 'other') return;
        const suggested = suggestVoucherInventoryCategory(nameInput.value);
        if (suggested) categorySelect.value = suggested;
    });
}

function initStockTxnModal() {
    document.getElementById('stockTxnModalClose')?.addEventListener('click', closeStockTxnModal);
    document.getElementById('stockTxnModalCancel')?.addEventListener('click', closeStockTxnModal);
    document.getElementById('stockTxnModalConfirm')?.addEventListener('click', confirmStockTxnModal);
    document.getElementById('stockTxnModalMinimize')?.addEventListener('click', minimizeStockTxnModal);
    document.getElementById('stockTxnModalMaximize')?.addEventListener('click', toggleMaximizeStockTxnModal);
    document.getElementById('stockTxnModalRestore')?.addEventListener('click', restoreStockTxnModal);
    document.getElementById('stockTxnModal')?.addEventListener('click', (e) => {
        if (e.target?.id === 'stockTxnModal' && !e.target.classList.contains('is-minimized')) {
            closeStockTxnModal();
        }
    });
    setStockModalDate(todayIsoDate());
}
