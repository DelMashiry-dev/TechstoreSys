/* auth.js — login, roles, user management */

let currentUser = null;

function getRolePermissions(role) {
    return ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.viewer;
}

function canAccessModule(moduleId) {
    if (!currentUser) return false;
    const perms = getRolePermissions(currentUser.role);
    if (perms.modules.includes('*')) return true;
    if (moduleId === 'release-cut') return perms.canReleaseCut;
    if (moduleId === 'user-management') return perms.canManageUsers;
    return perms.modules.includes(moduleId);
}

function canEditData() {
    return !!(currentUser && getRolePermissions(currentUser.role).canEdit);
}

function canManageUsers() {
    return !!(currentUser && getRolePermissions(currentUser.role).canManageUsers);
}

function canBackup() {
    return !!(currentUser && getRolePermissions(currentUser.role).canBackup);
}

function canProcessReleaseCut() {
    return !!(currentUser && getRolePermissions(currentUser.role).canReleaseCut);
}

function loadSession() {
    try {
        const raw = sessionStorage.getItem(SESSION_KEY);
        if (!raw) return null;
        const session = JSON.parse(raw);
        if (!session?.userId) return null;
        const user = (appState.users || []).find((u) => u.id === session.userId && u.active !== false);
        return user || null;
    } catch (error) {
        return null;
    }
}

function saveSession(user) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({
        userId: user.id,
        username: user.username,
        loggedInAt: new Date().toISOString()
    }));
}

function clearSession() {
    sessionStorage.removeItem(SESSION_KEY);
}

function setLoginError(message) {
    const el = document.getElementById('loginError');
    if (!el) return;
    if (message) {
        el.textContent = message;
        el.classList.add('visible');
    } else {
        el.textContent = '';
        el.classList.remove('visible');
    }
}

async function attemptLogin(username, password) {
    if (dbConnected) {
        try {
            const data = await apiRequest('/api/login', {
                method: 'POST',
                body: JSON.stringify({
                    username: String(username || '').trim(),
                    password: String(password || '').trim()
                })
            });
            // Refresh users/state from DB after login
            const stateData = await apiRequest('/api/state');
            appState = mergeState(stateData.appState);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
            return { ok: true, user: data.user };
        } catch (error) {
            return { ok: false, message: error.message || 'Invalid username or password.' };
        }
    }

    const users = appState.users || [];
    const user = users.find((u) =>
        u.username.toLowerCase() === String(username || '').trim().toLowerCase()
    );
    const pwd = String(password || '').trim();
    if (!user || String(user.password || '') !== pwd) {
        return { ok: false, message: 'Invalid username or password.' };
    }
    if (user.active === false) {
        return { ok: false, message: 'This account is disabled. Contact an administrator.' };
    }
    return { ok: true, user };
}

function updateHeaderUser() {
    const nameEl = document.getElementById('headerUserName');
    const roleEl = document.getElementById('headerUserRole');
    const avatarEl = document.getElementById('headerUserAvatar');
    const signedInChip = document.getElementById('dashboardSignedInChip');
    if (!currentUser) {
        if (nameEl) nameEl.textContent = 'Not signed in';
        if (roleEl) {
            roleEl.textContent = '—';
            roleEl.className = 'role-badge';
        }
        if (signedInChip) signedInChip.textContent = 'Signed in: —';
        return;
    }
    if (nameEl) nameEl.textContent = currentUser.name || currentUser.username;
    if (roleEl) {
        roleEl.textContent = ROLE_LABELS[currentUser.role] || currentUser.role;
        roleEl.className = `role-badge role-${currentUser.role}`;
    }
    if (avatarEl) {
        const label = encodeURIComponent(currentUser.name || currentUser.username || 'User');
        avatarEl.src = `https://ui-avatars.com/api/?name=${label}&background=3498db&color=fff`;
    }
    if (signedInChip) {
        const role = ROLE_LABELS[currentUser.role] || currentUser.role;
        signedInChip.textContent = `Signed in: ${currentUser.name || currentUser.username} (${role})`;
    }
}

function applyAccessControl() {
    const roleClasses = [
        'role-admin', 'role-army_commander', 'role-brig_gs', 'role-brig_as', 'role-brig_qs',
        'role-director', 'role-deputy_director', 'role-aqso2', 'role-dir_aiad', 'role-dir_daf', 'role-dir_dp',
        'role-techstores_officer', 'role-rq', 'role-store_officer', 'role-orderly_clerk',
        'role-storeman', 'role-rp', 'role-workshop',
        'role-oc_sysadmin', 'role-oc_workshop', 'role-oc_compengr', 'role-oc_swengr',
        'role-oc_ictsec', 'role-oc_itts', 'role-oc_admin', 'role-oc_gate',
        'role-viewer', 'access-readonly'
    ];
    document.body.classList.remove(...roleClasses);
    if (!currentUser) return;

    document.body.classList.add(`role-${currentUser.role}`);
    if (!canEditData()) document.body.classList.add('access-readonly');

    document.querySelectorAll('.sidebar-menu a[data-target]').forEach((link) => {
        const target = link.getAttribute('data-target');
        const li = link.closest('li');
        if (!li) return;
        if (canAccessModule(target)) {
            li.classList.remove('nav-hidden');
        } else {
            li.classList.add('nav-hidden');
        }
    });

    document.querySelectorAll('.nav-submenu-toggle').forEach((toggle) => {
        const parentLi = toggle.closest('li');
        if (!parentLi) return;
        const anyVisible = Array.from(parentLi.querySelectorAll('.submenu a[data-target]'))
            .some((a) => canAccessModule(a.getAttribute('data-target')));
        parentLi.classList.toggle('nav-hidden', !anyVisible);
    });

    document.querySelectorAll('.nav-admin-only').forEach((el) => {
        el.classList.toggle('nav-hidden', !canManageUsers());
    });
    document.querySelectorAll('.admin-only').forEach((el) => {
        el.classList.toggle('nav-hidden', !canBackup());
    });

    const releaseNav = document.querySelector('.sidebar-menu a[data-target="release-cut"]')?.closest('li');
    if (releaseNav) releaseNav.classList.toggle('nav-hidden', !canProcessReleaseCut());

    document.querySelectorAll('.quick-action-btn').forEach((btn) => {
        const target = btn.dataset.target;
        btn.style.display = canAccessModule(target) ? '' : 'none';
    });

    const denied = document.getElementById('userMgmtDenied');
    const content = document.getElementById('userMgmtContent');
    if (denied && content) {
        const allowed = canManageUsers();
        denied.style.display = allowed ? 'none' : 'block';
        content.style.display = allowed ? 'block' : 'none';
    }
}

function enterApp(user) {
    currentUser = user;
    saveSession(user);
    document.body.classList.remove('app-locked');
    if (typeof closePasswordChangeModal === 'function') closePasswordChangeModal();
    updateHeaderUser();
    applyAccessControl();
    navigateToModule('dashboard', { clearHistory: true, skipHistory: true });
    if (typeof initCommandBoard === 'function') initCommandBoard();
    updateDashboard();
    if (typeof updateCommandBoard === 'function') updateCommandBoard();
    else updateSystemAlerts();
    if (canManageUsers()) renderUsersTable();
    showToast(`Welcome, ${user.name || user.username} (${ROLE_LABELS[user.role] || user.role})`);
}

async function logoutUser() {
    // Persist data first — logout must never wipe operational records
    if (typeof flushPersistentDatabase === 'function') {
        await flushPersistentDatabase();
    } else if (typeof saveStateNow === 'function') {
        await saveStateNow();
    }
    currentUser = null;
    clearSession();
    document.body.classList.add('app-locked');
    document.body.classList.remove(
        'role-admin', 'role-army_commander', 'role-brig_gs', 'role-brig_as', 'role-brig_qs',
        'role-director', 'role-deputy_director', 'role-aqso2', 'role-dir_aiad', 'role-dir_daf', 'role-dir_dp',
        'role-techstores_officer', 'role-rq', 'role-store_officer', 'role-orderly_clerk',
        'role-storeman', 'role-rp', 'role-workshop',
        'role-oc_sysadmin', 'role-oc_workshop', 'role-oc_compengr', 'role-oc_swengr',
        'role-oc_ictsec', 'role-oc_itts', 'role-oc_admin', 'role-oc_gate',
        'role-viewer', 'access-readonly'
    );
    updateHeaderUser();
    setLoginError('');
    const form = document.getElementById('loginForm');
    if (form) form.reset();
    document.getElementById('loginUsername')?.focus();
    showToast(
        dbConnected
            ? 'Signed out. Your data remains in the persistent database.'
            : 'Signed out. Start START-SYSTEM.bat next time so data is stored on disk.',
        'info'
    );
}

function renderUsersTable() {
    const tbody = document.getElementById('users-table-body');
    if (!tbody) return;
    const users = appState.users || [];
    tbody.innerHTML = users.map((user) => `
        <tr data-user-id="${escapeHtml(user.id)}">
            <td>${escapeHtml(user.name)}</td>
            <td>${escapeHtml(user.username)}</td>
            <td><span class="role-badge role-${escapeHtml(user.role)}">${escapeHtml(ROLE_LABELS[user.role] || user.role)}</span></td>
            <td>${user.active === false ? 'Disabled' : 'Active'}</td>
            <td>
                <button class="btn btn-ghost btn-sm btn-edit-user" type="button" data-user-id="${escapeHtml(user.id)}">Edit</button>
                <button class="btn btn-secondary btn-sm btn-toggle-user" type="button" data-user-id="${escapeHtml(user.id)}">
                    ${user.active === false ? 'Enable' : 'Disable'}
                </button>
            </td>
        </tr>
    `).join('') || '<tr><td colspan="5" class="empty-state">No users found.</td></tr>';
}

function resetUserForm() {
    document.getElementById('newUserName').value = '';
    document.getElementById('newUserUsername').value = '';
    document.getElementById('newUserPassword').value = '';
    document.getElementById('newUserRole').value = 'store_officer';
    document.getElementById('newUserUsername').dataset.editingId = '';
}

function saveUserFromForm() {
    if (!canManageUsers()) {
        showToast('Only administrators can manage users.', 'error');
        return;
    }
    const name = document.getElementById('newUserName').value.trim();
    const username = document.getElementById('newUserUsername').value.trim();
    const password = document.getElementById('newUserPassword').value;
    const role = document.getElementById('newUserRole').value;
    const editingId = document.getElementById('newUserUsername').dataset.editingId || '';

    if (!name || !username) {
        showToast('Name and username are required.', 'error');
        return;
    }
    if (!ROLE_PERMISSIONS[role]) {
        showToast('Invalid access level.', 'error');
        return;
    }

    if (!appState.users) appState.users = createDefaultUsers();

    const duplicate = appState.users.find((u) =>
        u.username.toLowerCase() === username.toLowerCase() && u.id !== editingId
    );
    if (duplicate) {
        showToast('That username is already in use.', 'error');
        return;
    }

    if (editingId) {
        const user = appState.users.find((u) => u.id === editingId);
        if (!user) {
            showToast('User not found.', 'error');
            return;
        }
        user.name = name;
        user.username = username;
        user.role = role;
        if (password) user.password = password;
        if (currentUser && currentUser.id === user.id) {
            currentUser = { ...user };
            updateHeaderUser();
            applyAccessControl();
        }
        showToast('User updated successfully.');
    } else {
        if (!password) {
            showToast('Password is required for new users.', 'error');
            return;
        }
        appState.users.push({
            id: 'u-' + Date.now(),
            name,
            username,
            password,
            role,
            active: true,
            mustChangePassword: false
        });
        showToast('User created successfully.');
    }

    saveState();
    resetUserForm();
    renderUsersTable();
}

function editUser(userId) {
    const user = (appState.users || []).find((u) => u.id === userId);
    if (!user) return;
    document.getElementById('newUserName').value = user.name || '';
    document.getElementById('newUserUsername').value = user.username || '';
    document.getElementById('newUserPassword').value = '';
    document.getElementById('newUserPassword').placeholder = 'Leave blank to keep current password';
    document.getElementById('newUserRole').value = user.role;
    document.getElementById('newUserUsername').dataset.editingId = user.id;
}

function toggleUserActive(userId) {
    if (!canManageUsers()) return;
    const user = (appState.users || []).find((u) => u.id === userId);
    if (!user) return;
    if (currentUser && currentUser.id === user.id) {
        showToast('You cannot disable your own account while signed in.', 'error');
        return;
    }
    user.active = user.active === false;
    saveState();
    renderUsersTable();
    showToast(`User ${user.active === false ? 'disabled' : 'enabled'}.`);
}
