/* universal-search.js — app-wide jump-to search (modules, GLs, Q forms, records) */

const UNIVERSAL_SEARCH_HISTORY_KEY = 'universal';

function collectUniversalSearchIndex() {
    const items = [];
    const seen = new Set();

    const add = (entry) => {
        if (!entry?.id || seen.has(entry.id + '|' + (entry.kind || ''))) return;
        if (typeof canAccessModule === 'function' && entry.moduleId && !canAccessModule(entry.moduleId)) return;
        seen.add(entry.id + '|' + (entry.kind || ''));
        items.push(entry);
    };

    // Sidebar / known modules
    document.querySelectorAll('.sidebar-menu a[data-target]').forEach((a) => {
        const id = a.getAttribute('data-target');
        if (!id) return;
        const label = (typeof getModuleLabel === 'function' ? getModuleLabel(id) : '')
            || a.querySelector('.nav-label')?.textContent?.trim()
            || id;
        const group = a.closest('.submenu') ? 'Q / QM Forms' : 'Modules';
        add({
            id: `mod-${id}`,
            kind: 'module',
            moduleId: id,
            title: label,
            subtitle: group,
            haystack: `${id} ${label} ${group}`.toLowerCase()
        });
    });

    // GL accounts
    if (typeof GL_ACCOUNTS !== 'undefined') {
        Object.keys(GL_ACCOUNTS).forEach((code) => {
            const name = GL_ACCOUNTS[code]?.name || '';
            const moduleId = `gl-${code === '6122100009' ? '2200600002' : code}`;
            add({
                id: `gl-${code}`,
                kind: 'gl',
                moduleId,
                title: `GL ${code}`,
                subtitle: name,
                haystack: `gl ${code} ${name}`.toLowerCase()
            });
        });
    }

    // Q catalogue (in-system + reference → index)
    if (typeof ZNA_Q_CATALOGUE !== 'undefined') {
        ZNA_Q_CATALOGUE.forEach((e) => {
            const title = `ZNA-Q-${e.code} — ${e.title}`;
            add({
                id: `q-${e.code}`,
                kind: e.moduleId ? 'q-form' : 'q-ref',
                moduleId: e.moduleId || 'zna-q-forms-index',
                title,
                subtitle: e.moduleId ? 'In system' : 'Reference · open Index',
                haystack: `zna-q-${e.code} q${e.code} ${e.title} ${e.scope || ''}`.toLowerCase(),
                qCode: e.code
            });
        });
    }

    // Open unit requisitions
    const reqs = typeof ensureRequisitions === 'function' ? ensureRequisitions() : (appState?.requisitions || []);
    (reqs || []).slice(0, 80).forEach((req) => {
        const title = `${req.reqNo || 'Req'} — ${req.unit || ''} ${req.itemDescription || ''}`.trim();
        add({
            id: `req-${req.id}`,
            kind: 'requisition',
            moduleId: 'unit-requisitions',
            title,
            subtitle: `Requisition · ${req.status || ''}`,
            haystack: `${req.reqNo || ''} ${req.unit || ''} ${req.itemDescription || ''} ${req.category || ''}`.toLowerCase(),
            reqId: req.id
        });
    });

    // Undelivered POs
    const und = typeof ensureUndelivered === 'function' ? ensureUndelivered() : (appState?.undeliveredOrders || []);
    (und || []).slice(0, 80).forEach((row) => {
        const title = `${row.poNo || 'PO'} — ${row.item || ''}`.trim();
        add({
            id: `und-${row.id}`,
            kind: 'undelivered',
            moduleId: 'undelivered-orders',
            title,
            subtitle: `Undelivered · ${row.supplier || ''}`,
            haystack: `${row.poNo || ''} ${row.item || ''} ${row.supplier || ''}`.toLowerCase(),
            undId: row.id
        });
    });

    // DP procurements
    const dps = typeof ensureDpProcurements === 'function' ? ensureDpProcurements() : (appState?.dpProcurements || []);
    (dps || []).slice(0, 80).forEach((rec) => {
        const title = `${rec.refNo || 'DP F1'} — ${rec.itemSummary || ''}`.trim();
        add({
            id: `dp-${rec.id}`,
            kind: 'dp',
            moduleId: 'dp-procurement',
            title,
            subtitle: `Procurement · ${rec.status || ''}`,
            haystack: `${rec.refNo || ''} ${rec.itemSummary || ''} ${rec.status || ''}`.toLowerCase(),
            dpId: rec.id
        });
    });

    return items;
}

function rankUniversalHit(item, query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return item.kind === 'module' ? 5 : 1;
    const h = item.haystack || '';
    const t = (item.title || '').toLowerCase();
    if (t === q || h === q) return 100;
    if (t.startsWith(q) || h.startsWith(q)) return 90;
    if (h.includes(` ${q}`) || t.includes(` ${q}`)) return 70;
    if (h.includes(q)) return 50;
    const tokens = q.split(/\s+/).filter(Boolean);
    if (tokens.length && tokens.every((tok) => h.includes(tok))) return 40;
    return 0;
}

function searchUniversal(query, limit = 12) {
    const q = String(query || '').trim();
    return collectUniversalSearchIndex()
        .map((item) => ({ item, score: rankUniversalHit(item, q) }))
        .filter((r) => r.score > 0)
        .sort((a, b) => b.score - a.score || a.item.title.localeCompare(b.item.title))
        .slice(0, limit)
        .map((r) => r.item);
}

function ensureUniversalSearchUi() {
    if (document.getElementById('universalSearchModal')) return;
    const modal = document.createElement('div');
    modal.id = 'universalSearchModal';
    modal.className = 'universal-search-modal';
    modal.hidden = true;
    modal.innerHTML = `
        <div class="universal-search-backdrop" data-us-close></div>
        <div class="universal-search-panel" role="dialog" aria-modal="true" aria-labelledby="universalSearchTitle">
            <div class="universal-search-head">
                <h3 id="universalSearchTitle">Universal search</h3>
                <kbd class="universal-search-hint">Esc</kbd>
            </div>
            <input type="search" id="universalSearchInput" class="form-control universal-search-input"
                placeholder="Search modules, GLs, Q forms, requisitions, POs…"
                data-search-history-key="${UNIVERSAL_SEARCH_HISTORY_KEY}"
                autocomplete="off" spellcheck="false">
            <div id="universalSearchResults" class="universal-search-results" role="listbox"></div>
            <p class="universal-search-foot muted">Tip: press <kbd>Ctrl</kbd>+<kbd>K</kbd> anywhere · Enter to open</p>
        </div>`;
    document.body.appendChild(modal);

    modal.querySelector('[data-us-close]')?.addEventListener('click', closeUniversalSearch);
    const input = document.getElementById('universalSearchInput');
    input?.addEventListener('input', () => renderUniversalSearchResults(input.value));
    input?.addEventListener('keydown', (e) => {
        const list = document.getElementById('universalSearchResults');
        const items = [...(list?.querySelectorAll('[data-us-index]') || [])];
        const active = list?.querySelector('.is-active');
        let idx = active ? Number(active.getAttribute('data-us-index')) : -1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            idx = Math.min(items.length - 1, idx + 1);
            setUniversalActive(idx);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            idx = Math.max(0, idx - 1);
            setUniversalActive(idx);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            const pick = list?.querySelector('.is-active') || items[0];
            if (pick) activateUniversalResult(pick);
        } else if (e.key === 'Escape') {
            e.preventDefault();
            closeUniversalSearch();
        }
    });
    document.getElementById('universalSearchResults')?.addEventListener('click', (e) => {
        const row = e.target.closest('[data-us-index]');
        if (row) activateUniversalResult(row);
    });
}

function setUniversalActive(idx) {
    const list = document.getElementById('universalSearchResults');
    if (!list) return;
    list.querySelectorAll('[data-us-index]').forEach((el) => {
        el.classList.toggle('is-active', Number(el.getAttribute('data-us-index')) === idx);
    });
    list.querySelector('.is-active')?.scrollIntoView({ block: 'nearest' });
}

function kindBadge(kind) {
    const map = {
        module: 'Module',
        gl: 'GL',
        'q-form': 'Q form',
        'q-ref': 'Q ref',
        requisition: 'Req',
        undelivered: 'PO',
        dp: 'DP'
    };
    return map[kind] || 'Go';
}

function escapeUs(v) {
    return String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function renderUniversalSearchResults(query) {
    const host = document.getElementById('universalSearchResults');
    if (!host) return;
    const hits = searchUniversal(query, 14);
    if (!hits.length) {
        host.innerHTML = `<div class="universal-search-empty">No matches for “${escapeUs(query)}”.</div>`;
        return;
    }
    host.innerHTML = hits.map((item, i) => `
        <button type="button" class="universal-search-item${i === 0 ? ' is-active' : ''}"
            role="option" data-us-index="${i}"
            data-module="${escapeUs(item.moduleId || '')}"
            data-req-id="${escapeUs(item.reqId || '')}"
            data-und-id="${escapeUs(item.undId || '')}"
            data-dp-id="${escapeUs(item.dpId || '')}"
            data-q-code="${escapeUs(item.qCode || '')}">
            <span class="universal-search-badge">${escapeUs(kindBadge(item.kind))}</span>
            <span class="universal-search-text">
                <strong>${escapeUs(item.title)}</strong>
                <small>${escapeUs(item.subtitle || '')}</small>
            </span>
        </button>
    `).join('');
}

function activateUniversalResult(el) {
    const moduleId = el.getAttribute('data-module');
    const reqId = el.getAttribute('data-req-id');
    const undId = el.getAttribute('data-und-id');
    const dpId = el.getAttribute('data-dp-id');
    const qCode = el.getAttribute('data-q-code');
    const q = document.getElementById('universalSearchInput')?.value || '';
    if (q && typeof rememberSearchTerm === 'function') {
        rememberSearchTerm(UNIVERSAL_SEARCH_HISTORY_KEY, q);
    }
    closeUniversalSearch();
    if (!moduleId || typeof navigateToModule !== 'function') return;
    navigateToModule(moduleId);
    setTimeout(() => {
        if (reqId && typeof editRequisition === 'function') editRequisition(reqId);
        if (undId && typeof editUndelivered === 'function') editUndelivered(undId);
        if (dpId && typeof editDpProcurement === 'function') editDpProcurement(dpId);
        if (qCode && moduleId === 'zna-q-forms-index') {
            const search = document.getElementById('znaQIndexSearch');
            if (search) {
                search.value = qCode;
                search.dispatchEvent(new Event('input'));
            }
        }
    }, 60);
}

function openUniversalSearch(prefill = '') {
    if (document.body.classList.contains('app-locked')) return;
    ensureUniversalSearchUi();
    const modal = document.getElementById('universalSearchModal');
    const input = document.getElementById('universalSearchInput');
    if (!modal || !input) return;
    modal.hidden = false;
    document.body.classList.add('universal-search-open');
    input.value = prefill || '';
    renderUniversalSearchResults(input.value);
    requestAnimationFrame(() => {
        input.focus();
        input.select();
    });
}

function closeUniversalSearch() {
    const modal = document.getElementById('universalSearchModal');
    if (modal) modal.hidden = true;
    document.body.classList.remove('universal-search-open');
}

function initUniversalSearch() {
    if (document.body.dataset.universalSearchInit === '1') return;
    document.body.dataset.universalSearchInit = '1';
    ensureUniversalSearchUi();

    // Event delegation — works even if buttons are re-rendered
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-universal-search], #universalSearchBtn, #headerSearchBtn');
        if (!btn) return;
        e.preventDefault();
        openUniversalSearch();
    });

    const dashInput = document.getElementById('dashboardUniversalSearchInput');
    if (dashInput) {
        const openFromField = (e) => {
            e.preventDefault();
            openUniversalSearch(String(dashInput.value || '').trim());
        };
        dashInput.addEventListener('focus', openFromField);
        dashInput.addEventListener('click', openFromField);
        dashInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') openFromField(e);
        });
    }

    document.addEventListener('keydown', (e) => {
        if (document.body.classList.contains('app-locked')) return;
        const tag = (e.target && e.target.tagName) || '';
        const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || e.target?.isContentEditable;
        if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === 'k') {
            e.preventDefault();
            openUniversalSearch();
            return;
        }
        if (!typing && e.key === '/' && !e.ctrlKey && !e.metaKey && !e.altKey) {
            e.preventDefault();
            openUniversalSearch();
        }
        if (e.key === 'Escape' && document.body.classList.contains('universal-search-open')) {
            closeUniversalSearch();
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initUniversalSearch();
});
// Also init after late boot in case DOMContentLoaded already fired
if (document.readyState !== 'loading') {
    setTimeout(initUniversalSearch, 0);
}
