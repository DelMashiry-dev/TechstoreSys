/* dashboard.js — KPIs, navigation, release cut, theme */

function getModuleLabel(moduleId) {
    const labels = {
        'dashboard': 'Dashboard Overview',
        'gl-2200600002': 'GL 6122100009 - ZOFF / Office Supplies & Services',
        'gl-2200600003': 'GL 2200600003 - Software Licenses',
        'gl-220200002': 'GL 220200002 - Tech Equipment Maintenance',
        'gl-3112210001': 'GL 3112210001 - ICT Equipment',
        'gl-2201900002': 'GL 2201900002 - Spare Parts',
        'voucher-module': 'Issue Voucher',
        'stock-take': 'Stock Take — Full Stores Inventory',
        'unit-checks': 'Unit Check Log — ASO Ch 28',
        'financial-year-bids': 'Financial Year Bids',
        'unit-equipment': 'Unit Equipment',
        'ict-accountability': 'ZNA ICT Asset Register',
        'temporary-loans': 'Temporary Loans — Controlled Stores',
        'orderly-room': 'Orderly Room — DF & Correspondence Files',
        'unit-requisitions': 'Unit / Formation Requisitions',
        'monthly-returns': 'Monthly Returns — Unit ICT Equipment',
        'spec-evaluation': 'Spec Evaluation Form',
        'dp-f1-form': 'DP F1 Form',
        'stores-inventory': 'Stores Inventory',
        'inventory-accountability': 'Inventory Accountability',
        'dp-procurement': 'ICT Procurement Cycle',
        'zna-q-982': 'ZNA Q 982 — Combined Indent',
        'zna-q-178': 'ZNA Q 178 — Sub Ledger Sheet',
        'zna-q-1033': 'ZNA Q 1033 — Issue & Receipt Voucher',
        'zna-q-1043': 'ZNA Q 1043 — Condemnation Certificate',
        'zna-q-80': 'ZNA Q 80 — Ledger Sheet',
        'zna-svcs-890': 'ZNA SVCS/890 — Demand / Issue',
        'zna-q-1179': 'ZNA Q 1179 — Clothing Issue Voucher',
        'zna-q-987': 'ZNA Q 987 — Stocktaking Certificate',
        'zna-q-3977': 'ZNA Q 3977 — Neglect / Damage Report',
        'zna-q-985': 'ZNA Q 985 — Discrepancy Report',
        'zna-q-1': 'ZNA Q 1 — Statement of stores lost or damaged to be written off',
        'zna-q-998': 'ZNA Q 998 — Statement of Loss / Damage / Destruction',
        'zna-q-1680': 'ZNA Q 1680 — Miscellaneous credit/debit voucher',
        'zna-q-forms-index': 'SUMMARY OF Q FORMS — Index',
        'zna-q-3': 'ZNA Q 3 — Issue to Government department on repayment',
        'zna-q-31': 'ZNA Q 31 — Cash purchase / receipt',
        'zna-q-40': 'ZNA Q 40 — Artisan tools list',
        'zna-q-1049': 'ZNA Q 1049 — Transfer voucher',
        'zna-q-1229': 'ZNA Q 1229 — Certificate of accidental breakage',
        'zna-q-1571': 'ZNA Q 1571 — Debit voucher',
        'zna-q-1954': 'ZNA Q 1954 — Recoveries from individuals',
        'zna-svcs-1045': 'ZNA SVCS 1045 — Workshop Indent',
        'zna-q-1157': 'ZNA Q 1157 — Clothing & Equipment Record',
        'accommodation-stores': 'Inventory of Accommodation Stores',
        'delivery-note': 'Delivery Note',
        'purchase-orders': 'Purchase Orders',
        'undelivered-orders': 'Undelivered Items',
        'workshop-repairs': 'IT Workshop Register',
        'gate-register': 'Gate Register (RP)',
        'techstores-equipment-register': 'TechStores Equipment Register',
        'suppliers-contracts': 'Suppliers and Contracts',
        'release-cut': 'Release Cut',
        'stores-inventory': 'Stores Inventory',
        'duties-roles': 'Duties & Roles — Storeman / QM / Controlled Stores NCO',
        'process-guides': 'Learning Centre — Process & Charts',
        'system-help': 'System Help',
        'reports-module': 'Reports',
        'techstores-period': 'TechStores Period Report',
        'user-management': 'User Management'
    };
    return labels[moduleId] || 'Record';
}

function getBidCommittedByGl() {
    const committed = {};
    Object.keys(GL_ACCOUNTS).forEach((gl) => { committed[gl] = 0; });

    const bids = appState.modules['financial-year-bids'];
    if (!bids || !bids.tables || !bids.tables['bids-table-body']) return committed;

    bids.tables['bids-table-body'].forEach((row) => {
        const cells = row.cells || [];
        const glSelect = cells[3];
        const qty = parseFloat(cells[5]?.value) || 0;
        const unitCost = parseFloat(cells[6]?.value) || 0;
        const totalCost = parseFloat(cells[7]?.value) || (qty * unitCost);
        const gl = glSelect?.value;
        if (gl && committed[gl] !== undefined) {
            committed[gl] += totalCost;
        }
    });

    return committed;
}

function getPurchaseOrderCommittedByGl() {
    const committed = {};
    Object.keys(GL_ACCOUNTS).forEach((gl) => { committed[gl] = 0; });

    const poModule = appState.modules['purchase-orders'];
    if (!poModule || !poModule.tables || !poModule.tables['purchase-orders-table-body']) {
        return committed;
    }

    poModule.tables['purchase-orders-table-body'].forEach((row) => {
        const cells = row.cells || [];
        const layout = detectPurchaseOrderRowLayout(cells);
        const glCell = layout.gl >= 0 ? cells[layout.gl] : null;
        const gl = glCell?.value;
        const amount = parseFloat(cells[layout.amount]?.value) || 0;
        if (gl && committed[gl] !== undefined && amount > 0) {
            committed[gl] += amount;
        }
    });

    return committed;
}

function getDpF1CommittedByGl() {
    const committed = {};
    Object.keys(GL_ACCOUNTS).forEach((gl) => { committed[gl] = 0; });

    const liveCost = document.getElementById('dpF1EstimatedCost')?.value;
    const liveGl = document.getElementById('dpF1Gl')?.value;
    let amount = parseFloat(String(liveCost || '').replace(/[^0-9.-]/g, '')) || 0;
    let gl = liveGl || '';

    if (!amount || !gl) {
        const dpForm = appState.modules['dp-f1-form'];
        const fields = dpForm?.fields || [];
        const byId = Object.fromEntries(fields.filter((f) => f.id).map((f) => [f.id, f]));
        if (!amount) {
            amount = parseFloat(String(byId.dpF1EstimatedCost?.value || '').replace(/[^0-9.-]/g, '')) || 0;
        }
        if (!gl) gl = byId.dpF1Gl?.value || '';
    }

    if (gl && committed[gl] !== undefined && amount > 0) {
        committed[gl] += amount;
    }

    return committed;
}

function getCommittedByGl() {
    const baseCommitted = getBaseCommittedByGl();
    const voucherImpact = getVoucherImpactByGl();
    const total = {};

    Object.keys(GL_ACCOUNTS).forEach((gl) => {
        total[gl] = (baseCommitted[gl] || 0) + (voucherImpact[gl] || 0);
    });

    return total;
}

function getGlBalance(gl) {
    if (typeof getGlMonthlyBalance === 'function') {
        return getGlMonthlyBalance(gl, typeof getSelectedGlTargetMonth === 'function' ? getSelectedGlTargetMonth() : undefined);
    }
    const budget = appState.glBudgets[gl] || 0;
    const baseCommitted = getBaseCommittedByGl()[gl] || 0;
    const voucherImpact = getVoucherImpactByGl()[gl] || 0;
    return budget - baseCommitted - voucherImpact;
}

function getBudgetStatus(budget, balance) {
    if (typeof getTargetStatus === 'function') return getTargetStatus(budget, balance);
    if (budget <= 0) return { label: 'No vote', className: 'status-neutral' };
    const ratio = balance / budget;
    if (ratio < 0) return { label: 'Overdrawn', className: 'status-critical' };
    if (ratio < 0.2) return { label: 'Low Balance', className: 'status-warning' };
    if (ratio < 0.5) return { label: 'Monitor', className: 'status-monitor' };
    return { label: 'On Track', className: 'status-healthy' };
}

function updateGlCard(card, gl, budget, committed, vouchers, breakdown) {
    const balance = budget - committed - vouchers;
    const committedPercent = budget > 0 ? Math.min(100, (committed / budget) * 100) : 0;
    const voucherPercent = budget > 0 ? Math.min(100 - committedPercent, Math.abs(vouchers) / budget * 100) : 0;
    const usedPercent = budget > 0 ? Math.min(100, ((committed + vouchers) / budget) * 100) : 0;

    card.querySelector('.budget-total').textContent = formatCurrency(budget);
    card.querySelector('.budget-committed').textContent = formatCurrency(committed);
    const vouchersEl = card.querySelector('.budget-vouchers');
    if (vouchersEl) {
        vouchersEl.textContent = (vouchers >= 0 ? '+' : '') + formatCurrency(vouchers);
        vouchersEl.style.color = vouchers > 0 ? 'var(--danger)' : vouchers < 0 ? 'var(--success)' : 'inherit';
    }
    const balanceEl = card.querySelector('.budget-balance');
    balanceEl.textContent = formatCurrency(balance);
    balanceEl.style.color = balance < budget * 0.2 ? 'var(--warning)' : 'var(--success)';

    const bidsEl = card.querySelector('.budget-bids');
    const posEl = card.querySelector('.budget-pos');
    const dpf1El = card.querySelector('.budget-dpf1');
    if (bidsEl) bidsEl.textContent = formatCurrency(breakdown.bids || 0);
    if (posEl) posEl.textContent = formatCurrency(breakdown.po || 0);
    if (dpf1El) dpf1El.textContent = formatCurrency(breakdown.dpF1 || 0);

    const committedBar = card.querySelector('[data-budget-bar-committed]');
    const voucherBar = card.querySelector('[data-budget-bar-vouchers]');
    if (committedBar) committedBar.style.width = committedPercent.toFixed(1) + '%';
    if (voucherBar) {
        voucherBar.style.width = voucherPercent.toFixed(1) + '%';
        voucherBar.classList.toggle('credit', vouchers < 0);
    }

    const utilizationEl = card.querySelector('[data-utilization]');
    if (utilizationEl) utilizationEl.textContent = usedPercent.toFixed(1) + '% utilized';

    const statusBadge = card.querySelector('[data-status-badge]');
    if (statusBadge) {
        const status = getBudgetStatus(budget, balance);
        statusBadge.textContent = status.label;
        statusBadge.className = 'card-status-badge ' + status.className;
    }

    return { budget, committed, vouchers, balance, usedPercent };
}

/** Default-collapsed secondary panels (user preference overrides once toggled). */
const DASH_COLLAPSE_DEFAULTS = {
    'portfolio-pulse': true,
    'gl-portfolio': true,
    'gl-target-overview': true,
    'inventory-recon': false
};

function getDashCollapseState() {
    try {
        return JSON.parse(localStorage.getItem('techstores_dash_collapse_v1') || '{}') || {};
    } catch (e) {
        return {};
    }
}

function setDashCollapseState(state) {
    try {
        localStorage.setItem('techstores_dash_collapse_v1', JSON.stringify(state || {}));
    } catch (e) { /* ignore */ }
}

function resolveDashCollapsed(key, stored) {
    if (Object.prototype.hasOwnProperty.call(stored, key)) return !!stored[key];
    return !!DASH_COLLAPSE_DEFAULTS[key];
}

function applyDashCollapsePanel(panel, collapsed) {
    if (!panel) return;
    panel.classList.toggle('is-collapsed', !!collapsed);
    const btn = panel.querySelector('.dash-collapse-toggle');
    if (btn) {
        btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        btn.title = collapsed ? 'Expand section' : 'Collapse section';
    }
}

function initDashboardCollapsibles() {
    const state = getDashCollapseState();
    document.querySelectorAll('.dash-collapse[data-collapse-key]').forEach((panel) => {
        const key = panel.getAttribute('data-collapse-key');
        if (!key) return;
        applyDashCollapsePanel(panel, resolveDashCollapsed(key, state));
        const btn = panel.querySelector('.dash-collapse-toggle');
        if (!btn || btn.dataset.collapseWired === '1') return;
        btn.dataset.collapseWired = '1';
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const next = !panel.classList.contains('is-collapsed');
            applyDashCollapsePanel(panel, next);
            const s = getDashCollapseState();
            s[key] = next;
            setDashCollapseState(s);
        });
    });
}

function renderBudgetOverviewTable(rows) {
    const tbody = document.getElementById('budgetOverviewBody');
    if (!tbody) return;

    const canEdit = typeof canEditData === 'function' ? canEditData() : true;
    const month = typeof getSelectedGlTargetMonth === 'function' ? getSelectedGlTargetMonth() : '';

    tbody.innerHTML = rows.map((row) => {
        const status = getBudgetStatus(row.budget, row.balance);
        const funding = row.fundingNote || '';
        const isTotal = row.code === 'ALL';
        const targetCell = isTotal || !canEdit
            ? formatCurrency(row.budget)
            : `<input type="number" class="form-control gl-target-input" min="0" step="0.01"
                    data-gl-target="${row.code}" value="${row.budget || 0}" title="DAF monthly target / vote for ${row.code}">`;
        return `
            <tr class="${isTotal ? 'gl-target-total-row' : ''} ${row.budget > 0 ? 'is-funded' : 'is-unfunded'}">
                <td><span class="gl-link" data-target="${row.target}">${row.code}</span><br><small>${row.name}</small>
                    ${!isTotal && funding ? `<div class="gl-funding-note">${funding}</div>` : ''}
                </td>
                <td>${targetCell}</td>
                <td>${formatCurrency(row.committed)}</td>
                <td>${(row.vouchers >= 0 ? '+' : '') + formatCurrency(row.vouchers)}</td>
                <td>${formatCurrency(row.expended != null ? row.expended : (row.committed + row.vouchers))}</td>
                <td><strong class="${row.balance < 0 ? 'buying-power-neg' : 'buying-power-ok'}">${formatCurrency(row.balance)}</strong></td>
                <td><span class="card-status-badge ${status.className}">${status.label}</span></td>
            </tr>
        `;
    }).join('');

    tbody.querySelectorAll('.gl-link').forEach((link) => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            navigateToModule(this.dataset.target);
        });
    });

    tbody.querySelectorAll('.gl-target-input').forEach((input) => {
        input.addEventListener('change', () => {
            const gl = input.getAttribute('data-gl-target');
            if (!gl || typeof setGlMonthlyTarget !== 'function') return;
            if (typeof requireEditAccess === 'function' && !requireEditAccess()) {
                updateDashboard();
                return;
            }
            setGlMonthlyTarget(gl, input.value, month);
            showToast(`DAF target recorded for GL ${gl} · ${typeof formatYmLabel === 'function' ? formatYmLabel(month) : month}. Buying power updated.`, 'success');
            updateDashboard();
            if (typeof refreshReleaseCutBuyingPowerHints === 'function') refreshReleaseCutBuyingPowerHints();
        });
    });
}

function renderRecentTransfers() {
    const listEl = document.getElementById('recentTransfersList');
    if (listEl) {
        const transfers = (appState.releaseCuts || []).slice(-8).reverse();
        if (!transfers.length) {
            listEl.innerHTML = '<li class="empty-state">No release cuts recorded yet.</li>';
        } else {
            listEl.innerHTML = transfers.map((transfer) => `
                <li class="transfer-item">
                    <div><span class="transfer-amount">${formatCurrency(transfer.amount)}</span> from GL ${transfer.fromGl} → GL ${transfer.toGl}</div>
                    <div><small>${transfer.date} · ${transfer.authorizedBy || 'Unknown'} · ${transfer.reason || 'No reason'}</small></div>
                </li>
            `).join('');
        }
    }
    renderReleaseCutsTable();
}

function renderReleaseCutsTable() {
    const tbody = document.getElementById('release-cuts-table-body');
    if (!tbody) return;

    const esc = (value) => String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

    const transfers = [...(appState.releaseCuts || [])].reverse();
    if (!transfers.length) {
        tbody.innerHTML = '<tr><td colspan="6">No release cuts recorded yet.</td></tr>';
        return;
    }

    tbody.innerHTML = transfers.map((transfer) => `
        <tr>
            <td>${esc(transfer.date || '')}</td>
            <td>${esc(transfer.fromGl || '')}</td>
            <td>${esc(transfer.toGl || '')}</td>
            <td>${formatCurrency(transfer.amount)}</td>
            <td>${esc(transfer.reason || '')}</td>
            <td>${esc(transfer.authorizedBy || '')}</td>
        </tr>
    `).join('');
}

function countModuleTableRows(moduleId, tbodyId) {
    const moduleData = appState.modules?.[moduleId];
    const rows = moduleData?.tables?.[tbodyId];
    if (Array.isArray(rows)) return rows.length;
    const liveBody = document.getElementById(tbodyId);
    return liveBody ? liveBody.querySelectorAll('tr').length : 0;
}

function updateOpsActivityStrip() {
    const setVal = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(value);
    };

    setVal('opsVoucherLines', countModuleTableRows('voucher-module', 'voucher-table-body'));
    setVal('opsBidLines', countModuleTableRows('financial-year-bids', 'bids-table-body'));
    setVal('opsPoLines', countModuleTableRows('purchase-orders', 'purchase-orders-table-body'));
    setVal('opsLoanLines', countModuleTableRows('temporary-loans', 'loans-table-body'));
    setVal('opsWorkshopLines', countModuleTableRows('workshop-repairs', 'workshop-repairs-table-body'));
    setVal('opsTransferCount', (appState.releaseCuts || []).length);
}

function updateDashboardKpis(summaryBudget, summaryCommitted, summaryVouchers, summaryBalance, breakdownTotals, alertCount) {
    const usedPercent = summaryBudget > 0 ? ((summaryCommitted + summaryVouchers) / summaryBudget) * 100 : 0;
    const status = getBudgetStatus(summaryBudget, summaryBalance);
    const committedPercent = summaryBudget > 0 ? Math.min(100, (summaryCommitted / summaryBudget) * 100) : 0;
    const voucherPercent = summaryBudget > 0
        ? Math.min(100 - committedPercent, (Math.abs(summaryVouchers) / summaryBudget) * 100)
        : 0;

    document.getElementById('kpiTotalBudget').textContent = formatCurrency(summaryBudget);
    document.getElementById('kpiTotalCommitted').textContent = formatCurrency(summaryCommitted);
    document.getElementById('kpiTotalBalance').textContent = formatCurrency(summaryBalance);
    document.getElementById('kpiUtilization').textContent = usedPercent.toFixed(1) + '%';
    document.getElementById('kpiAlertCount').textContent = String(alertCount);

    document.getElementById('kpiCommittedBreakdown').textContent =
        `Bids ${formatCurrency(breakdownTotals.bids)} · POs ${formatCurrency(breakdownTotals.po)} · DP F1 ${formatCurrency(breakdownTotals.dpF1)}`;
    document.getElementById('kpiVoucherImpact').textContent =
        `Vouchers: ${(summaryVouchers >= 0 ? '+' : '') + formatCurrency(summaryVouchers)}`;
    document.getElementById('kpiUtilizationStatus').textContent = status.label;

    const detail = document.getElementById('kpiUtilizationDetail');
    if (detail) detail.textContent = `${Math.max(0, usedPercent).toFixed(1)}% used`;

    const committedBar = document.getElementById('kpiUtilCommittedBar');
    const voucherBar = document.getElementById('kpiUtilVoucherBar');
    if (committedBar) committedBar.style.width = committedPercent.toFixed(1) + '%';
    if (voucherBar) {
        voucherBar.style.width = voucherPercent.toFixed(1) + '%';
        voucherBar.classList.toggle('credit', summaryVouchers < 0);
    }

    const lastUpdated = document.getElementById('dashboardLastUpdated');
    if (lastUpdated) {
        lastUpdated.textContent = new Date().toLocaleString('en-ZW', {
            dateStyle: 'medium',
            timeStyle: 'short'
        });
    }

    updateOpsActivityStrip();
    if (typeof updateBuyingPowerEmptyHints === 'function') {
        updateBuyingPowerEmptyHints(summaryBudget, summaryBalance);
    }
}

let navHistory = [];
let currentModuleId = 'dashboard';

function getActiveModuleId() {
    const visible = [...document.querySelectorAll('.content-section, .form-container')]
        .find((el) => el.style.display !== 'none' && el.id);
    return visible?.id || currentModuleId || 'dashboard';
}

async function navigateToModule(targetId, options = {}) {
    if (!targetId) return;
    if (typeof hideFieldHelp === 'function') hideFieldHelp();
    if (!currentUser) {
        document.body.classList.add('app-locked');
        return;
    }
    if (!canAccessModule(targetId)) {
        showToast('Access denied for your access level.', 'error');
        return;
    }

    const skipHistory = !!options.skipHistory;
    const clearHistory = !!options.clearHistory;
    const fromId = getActiveModuleId();

    if (clearHistory) {
        navHistory = [];
    } else if (!skipHistory && fromId && fromId !== targetId) {
        navHistory.push(fromId);
        if (navHistory.length > 40) navHistory.shift();
    }

    // Standalone module HTML — load on demand from app/modules/<id>.html
    if (targetId !== 'dashboard' && typeof ensureModuleLoaded === 'function') {
        try {
            await ensureModuleLoaded(targetId);
        } catch (err) {
            console.error(err);
            showToast(`Could not load module “${targetId}”.`, 'error');
            return;
        }
    }

    document.querySelectorAll('.content-section, .form-container').forEach((section) => {
        section.style.display = 'none';
        section.classList.remove('is-open');
    });

    const targetSection = document.getElementById(targetId);
    if (targetSection) {
        targetSection.style.display = 'block';
        targetSection.classList.remove('is-open');
    }
    document.querySelectorAll('.sidebar-menu a').forEach((link) => link.classList.remove('active'));
    const menuLink = document.querySelector(`.sidebar-menu a[data-target="${targetId}"]`);
    if (menuLink) menuLink.classList.add('active');
    currentModuleId = targetId;
    updateFormBackButtons();
    if (targetId === 'financial-year-bids') {
        if (typeof populateBidsPackSelect === 'function') populateBidsPackSelect();
        if (typeof initBidCalculations === 'function') initBidCalculations();
    }
    if (targetId === 'voucher-module' && typeof renderVoucherInventoryTables === 'function') {
        renderVoucherInventoryTables();
    }
    if (targetId === 'stock-take') {
        if (typeof initStockTakeModule === 'function') initStockTakeModule();
        if (typeof renderStockTakeTable === 'function') renderStockTakeTable();
    }
    if (targetId === 'unit-checks') {
        if (typeof initUnitChecksModule === 'function') initUnitChecksModule();
        if (typeof renderUnitChecksModule === 'function') renderUnitChecksModule();
    }
    if (targetId === 'unit-requisitions' && typeof renderRequisitionsModule === 'function') {
        renderRequisitionsModule();
    }
    if (targetId === 'orderly-room') {
        if (typeof initOrderlyRoomModule === 'function') initOrderlyRoomModule();
        if (typeof renderOrderlyRoomModule === 'function') renderOrderlyRoomModule();
        if (typeof initCorrespondenceFilesModule === 'function') initCorrespondenceFilesModule();
        if (typeof renderCorrespondenceFilesModule === 'function') renderCorrespondenceFilesModule();
    }
    if (typeof getDeptDeskDef === 'function' && getDeptDeskDef(targetId)) {
        if (typeof initDeptDeskModule === 'function') initDeptDeskModule(targetId);
        if (typeof renderDeptDeskModule === 'function') renderDeptDeskModule(targetId);
    }
    if (targetId === 'monthly-returns') {
        if (typeof initMonthlyReturnsModule === 'function') initMonthlyReturnsModule();
        if (typeof renderMonthlyReturnsModule === 'function') renderMonthlyReturnsModule();
    }
    if (targetId === 'unit-equipment' && typeof renderUnitEquipmentView === 'function') {
        setUnitEquipmentMode('view');
        renderUnitEquipmentView();
    }
    if (targetId === 'temporary-loans' && typeof renderTemporaryLoansView === 'function') {
        setTemporaryLoansMode('view');
        renderTemporaryLoansView();
    }
    if (targetId === 'ict-accountability' && typeof renderIctAccountabilityTable === 'function') {
        if (typeof initIctAccountabilityModule === 'function') initIctAccountabilityModule();
        renderIctAccountabilityTable();
    }
    if (targetId === 'undelivered-orders' && typeof renderUndeliveredModule === 'function') {
        renderUndeliveredModule();
    }
    if (targetId === 'zna-q-forms-index' && typeof renderZnaQFormsIndex === 'function') {
        renderZnaQFormsIndex();
    }
    if (targetId === 'duties-roles') {
        if (typeof initDutiesRolesModule === 'function') initDutiesRolesModule();
        if (typeof renderDutiesRolesModule === 'function') renderDutiesRolesModule();
    }
    if (targetId === 'process-guides') {
        if (typeof initProcessGuidesModule === 'function') initProcessGuidesModule();
        if (typeof renderProcessGuidesContent === 'function') renderProcessGuidesContent();
    }
    if (targetId === 'system-help' && typeof initRetentionReminder === 'function') {
        initRetentionReminder();
    }
    if (targetId === 'dp-f1-form' && typeof updateDpF1SendStatus === 'function') {
        updateDpF1SendStatus();
    }
    if (targetId === 'dp-procurement' && typeof renderDpProcurementModule === 'function') {
        renderDpProcurementModule();
    }
    if (targetId === 'suppliers-contracts' && typeof renderSuppliersView === 'function') {
        renderSuppliersView();
    }
    if (typeof getGlInventoryModuleConfig === 'function' && getGlInventoryModuleConfig(targetId)) {
        setTimeout(() => {
            if (typeof setGlInventoryMode === 'function') {
                setGlInventoryMode(targetId, options.glMode === 'edit' ? 'edit' : 'view');
            }
        }, 0);
    }
    if (targetId === 'gate-register' || targetId === 'techstores-equipment-register' || targetId === 'workshop-repairs') {
        if (typeof initRepairIntakeModules === 'function') initRepairIntakeModules();
        if (typeof ensureRepairIntakeTables === 'function') ensureRepairIntakeTables();
        if (typeof initModuleMessagingPortal === 'function') initModuleMessagingPortal(targetId);
    }
    if (targetId === 'user-management' && canManageUsers()) renderUsersTable();
    if (typeof enhanceFieldHelp === 'function') {
        setTimeout(() => enhanceFieldHelp(document.getElementById(targetId) || document), 50);
    }
}

async function navigateBack() {
    while (navHistory.length) {
        const prev = navHistory.pop();
        if (!prev || prev === currentModuleId) continue;
        if (typeof canAccessModule === 'function' && !canAccessModule(prev)) continue;
        if (typeof ensureModuleLoaded === 'function') {
            try { await ensureModuleLoaded(prev); } catch (e) { continue; }
        } else if (!document.getElementById(prev)) {
            continue;
        }
        await navigateToModule(prev, { skipHistory: true });
        return;
    }
    await navigateToModule('dashboard', { skipHistory: true, clearHistory: true });
}

function initFormBackButtons() {
    document.querySelectorAll('.form-container .form-header').forEach((header) => {
        if (header.querySelector('.btn-nav-back')) return;

        const backBtn = document.createElement('button');
        backBtn.type = 'button';
        backBtn.className = 'btn-nav-back';
        backBtn.setAttribute('aria-label', 'Go back');
        backBtn.title = 'Back to previous screen';
        backBtn.innerHTML = '<span aria-hidden="true">←</span><span class="btn-nav-back-label">Back</span>';
        backBtn.addEventListener('click', (e) => {
            e.preventDefault();
            navigateBack();
        });

        // Only reposition a direct-child .form-title — nested titles break insertBefore/appendChild
        const title = Array.from(header.children).find((el) => el.classList?.contains('form-title'));
        if (title) {
            const start = document.createElement('div');
            start.className = 'form-header-start';
            header.insertBefore(start, title);
            start.appendChild(backBtn);
            start.appendChild(title);
        } else {
            header.insertBefore(backBtn, header.firstChild);
        }
    });
    updateFormBackButtons();
}

function updateFormBackButtons() {
    const canGoBack = navHistory.length > 0;
    document.querySelectorAll('.btn-nav-back').forEach((btn) => {
        btn.disabled = false;
        btn.classList.toggle('is-fallback-dashboard', !canGoBack);
        btn.title = canGoBack ? 'Back to previous screen' : 'Back to dashboard';
    });
}

function updateDashboard() {
    const month = typeof getSelectedGlTargetMonth === 'function'
        ? setSelectedGlTargetMonth(getSelectedGlTargetMonth())
        : '';
    const bidByGl = getBidCommittedByGl();
    const poByGl = typeof getPurchaseOrderCommittedByGlForMonth === 'function'
        ? getPurchaseOrderCommittedByGlForMonth(month)
        : getPurchaseOrderCommittedByGl();
    const dpF1ByGl = getDpF1CommittedByGl();
    const baseCommittedByGl = typeof getBaseCommittedByGlForMonth === 'function'
        ? getBaseCommittedByGlForMonth(month)
        : getBaseCommittedByGl();
    const voucherByGl = typeof getVoucherImpactByGlForMonth === 'function'
        ? getVoucherImpactByGlForMonth(month)
        : getVoucherImpactByGl();

    let summaryBudget = 0;
    let summaryCommitted = 0;
    let summaryVouchers = 0;
    const overviewRows = [];
    const breakdownTotals = { bids: 0, po: 0, dpF1: 0 };

    Object.keys(GL_ACCOUNTS).forEach((gl) => {
        breakdownTotals.bids += bidByGl[gl] || 0;
        breakdownTotals.po += poByGl[gl] || 0;
        breakdownTotals.dpF1 += dpF1ByGl[gl] || 0;
    });

    document.querySelectorAll('.card[data-gl]').forEach((card) => {
        const gl = card.getAttribute('data-gl');
        if (gl === 'summary') return;

        const budget = typeof getGlMonthlyTarget === 'function'
            ? getGlMonthlyTarget(gl, month)
            : (appState.glBudgets[gl] || 0);
        const committed = baseCommittedByGl[gl] || 0;
        const vouchers = voucherByGl[gl] || 0;
        const breakdown = {
            bids: bidByGl[gl] || 0,
            po: poByGl[gl] || 0,
            dpF1: dpF1ByGl[gl] || 0
        };

        const totals = updateGlCard(card, gl, budget, committed, vouchers, breakdown);
        summaryBudget += totals.budget;
        summaryCommitted += totals.committed;
        summaryVouchers += totals.vouchers;

        overviewRows.push({
            code: gl,
            name: GL_ACCOUNTS[gl].name,
            target: card.getAttribute('data-target'),
            budget: totals.budget,
            committed: totals.committed,
            vouchers: totals.vouchers,
            expended: totals.committed + totals.vouchers,
            balance: totals.balance,
            fundingNote: typeof getGlFundingNote === 'function' ? getGlFundingNote(gl, month) : ''
        });
    });

    const summaryCard = document.querySelector('.card[data-gl="summary"]');
    if (summaryCard) {
        const summaryBalance = summaryBudget - summaryCommitted - summaryVouchers;
        updateGlCard(summaryCard, 'summary', summaryBudget, summaryCommitted, summaryVouchers, breakdownTotals);
        overviewRows.push({
            code: 'ALL',
            name: month ? `Month total · ${typeof formatYmLabel === 'function' ? formatYmLabel(month) : month}` : 'Financial Year Total',
            target: 'financial-year-bids',
            budget: summaryBudget,
            committed: summaryCommitted,
            vouchers: summaryVouchers,
            expended: summaryCommitted + summaryVouchers,
            balance: summaryBalance,
            fundingNote: ''
        });
    }

    const alertCount = typeof updateCommandBoard === 'function'
        ? updateCommandBoard()
        : updateSystemAlerts();
    updateDashboardKpis(summaryBudget, summaryCommitted, summaryVouchers, summaryBudget - summaryCommitted - summaryVouchers, breakdownTotals, alertCount);
    renderBudgetOverviewTable(overviewRows);
    renderInventoryDashboard();
    renderRecentTransfers();
    if (typeof initDashboardCollapsibles === 'function') initDashboardCollapsibles();
}

function processReleaseCut() {
    if (!canProcessReleaseCut()) {
        showToast('Only Administrators can process Release Cut transfers.', 'error');
        return;
    }
    const date = document.getElementById('releaseCutDate').value;
    const fromGl = document.getElementById('releaseCutFrom').value;
    const toGl = document.getElementById('releaseCutTo').value;
    const amount = parseFloat(document.getElementById('releaseCutAmount').value) || 0;
    const reason = document.getElementById('releaseCutReason').value.trim();
    const authorizedBy = document.getElementById('releaseCutAuthorized').value.trim();

    if (!date) {
        showToast('Please select a transfer date.', 'error');
        return;
    }
    if (fromGl === toGl) {
        showToast('Source and destination GL accounts must be different.', 'error');
        return;
    }
    if (amount <= 0) {
        showToast('Transfer amount must be greater than zero.', 'error');
        return;
    }
    if (!reason) {
        showToast('Please enter a reason for the transfer.', 'error');
        return;
    }
    if (!authorizedBy) {
        showToast('Please enter the authorizing officer.', 'error');
        return;
    }

    const fromBalance = getGlBalance(fromGl);
    if (amount > fromBalance) {
        showToast(`Insufficient monthly target balance on GL ${fromGl}. Available: ${formatCurrency(fromBalance)}`, 'error');
        return;
    }

    if (typeof applyMonthlyReleaseCut === 'function') {
        const result = applyMonthlyReleaseCut({ date, fromGl, toGl, amount });
        if (!result.ok) {
            showToast(result.error || 'Release Cut failed.', 'error');
            return;
        }
    } else {
        appState.glBudgets[fromGl] = (appState.glBudgets[fromGl] || 0) - amount;
        appState.glBudgets[toGl] = (appState.glBudgets[toGl] || 0) + amount;
    }

    appState.releaseCuts.push({
        date,
        fromGl,
        toGl,
        amount,
        reason,
        authorizedBy,
        month: String(date).slice(0, 7),
        processedAt: new Date().toISOString()
    });

    saveState();
    if (typeof setSelectedGlTargetMonth === 'function') {
        setSelectedGlTargetMonth(String(date).slice(0, 7));
    }
    updateDashboard();

    document.getElementById('releaseCutAmount').value = '';
    document.getElementById('releaseCutReason').value = '';
    document.getElementById('releaseCutAuthorized').value = '';

    showToast(`Release Cut: moved ${formatCurrency(amount)} buying power from GL ${fromGl} → GL ${toGl} (${String(date).slice(0, 7)}).`);
    if (typeof refreshReleaseCutBuyingPowerHints === 'function') refreshReleaseCutBuyingPowerHints();
}

function restoreAllModules() {
    MODULE_IDS.forEach((moduleId) => {
        if (appState.modules[moduleId]) {
            restoreModule(moduleId, appState.modules[moduleId]);
        }
    });
}


