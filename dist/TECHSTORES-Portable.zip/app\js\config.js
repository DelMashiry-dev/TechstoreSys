const STORAGE_KEY = 'techstores_gl_v1';
const SESSION_KEY = 'techstores_session_v1';
const API_BASE = '';

let dbConnected = false;
let saveTimer = null;

const ROLE_LABELS = {
    admin: 'Administrator',
    army_commander: "Army Commander (ZNA)",
    brig_gs: 'Brigadier GS',
    brig_as: 'Brigadier AS',
    brig_qs: 'Brigadier QS',
    director: 'Director IT Dir (Col)',
    deputy_director: 'Deputy Director (Lt Col)',
    aqso2: 'AQSO2 (Maj)',
    dir_aiad: 'Director AIAD',
    dir_daf: 'Director DAF',
    dir_dp: 'Director DP',
    techstores_officer: 'TechStores Officer',
    rq: 'Regimental Quartermaster (RQ)',
    store_officer: 'Store Officer',
    orderly_clerk: 'Orderly Room / Chief Clerk',
    storeman: 'Storeman (Cpl)',
    rp: 'Regimental Police (RP)',
    workshop: 'Workshop Personnel',
    oc_sysadmin: 'OC Systems Administration',
    oc_workshop: 'OC Workshop / Engr Support',
    oc_compengr: 'OC Computer Engineering / DBA',
    oc_swengr: 'OC Software Engineering',
    oc_ictsec: 'OC ICT Security',
    oc_itts: 'OC ITTS',
    oc_admin: 'Admin Office / AO',
    oc_gate: 'Gate / RP Desk',
    viewer: 'Viewer'
};

/** Full operational module set (no user-mgmt / release-cut — those use flags). */
const MODULES_DEPT_DESKS = [
    'dept-sysadmin', 'dept-workshop', 'dept-compengr', 'dept-swengr',
    'dept-ictsec', 'dept-itts', 'dept-admin', 'dept-gate'
];

const MODULES_FULL_OPS = [
    'dashboard', 'orderly-room',
    ...MODULES_DEPT_DESKS,
    'gl-2200600002', 'gl-2200600003', 'gl-220200002', 'gl-2201900002', 'gl-3112210001',
    'voucher-module', 'stock-take', 'unit-checks', 'financial-year-bids', 'unit-equipment', 'ict-accountability', 'temporary-loans',
    'unit-requisitions', 'monthly-returns', 'undelivered-orders',
    'spec-evaluation', 'dp-f1-form', 'dp-procurement', 'zna-q-982', 'zna-q-178', 'zna-q-1033', 'zna-q-1043',
    'zna-q-80', 'zna-svcs-890', 'zna-q-1179', 'zna-q-987', 'zna-q-3977', 'zna-svcs-1045', 'zna-q-1157',
    'zna-q-985', 'zna-q-1', 'zna-q-998', 'zna-q-1680',
    'zna-q-forms-index', 'zna-q-3', 'zna-q-31', 'zna-q-40', 'zna-q-1049', 'zna-q-1229', 'zna-q-1571', 'zna-q-1954',
    'accommodation-stores',
    'delivery-note', 'purchase-orders', 'workshop-repairs',
    'gate-register', 'techstores-equipment-register',
    'suppliers-contracts', 'duties-roles', 'process-guides', 'system-help', 'reports-module'
];

function modulesForDeptDesk(deskId, extras = []) {
    return ['dashboard', deskId, 'unit-requisitions', ...extras, 'process-guides', 'system-help'];
}

const MODULES_STOREMAN = [
    'dashboard',
    'voucher-module', 'stock-take', 'delivery-note', 'temporary-loans',
    'unit-requisitions', 'undelivered-orders',
    'zna-q-1033', 'zna-svcs-890', 'zna-svcs-1045',
    'techstores-equipment-register', 'workshop-repairs',
    'duties-roles', 'process-guides', 'system-help'
];

const MODULES_RP = [
    'dashboard', 'dept-gate', 'gate-register', 'process-guides', 'system-help'
];

const MODULES_WORKSHOP = [
    'dashboard', 'dept-workshop',
    'workshop-repairs', 'zna-svcs-1045', 'zna-q-1043',
    'techstores-equipment-register', 'unit-requisitions', 'process-guides', 'system-help'
];

const MODULES_ORDERLY = [
    'dashboard', 'orderly-room', 'unit-requisitions', 'dp-procurement',
    ...MODULES_DEPT_DESKS, 'process-guides', 'system-help', 'reports-module'
];

const ROLE_PERMISSIONS = {
    admin: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: true,
        canManageUsers: true,
        canBackup: true,
        canReports: true
    },
    army_commander: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    brig_gs: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    brig_as: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    brig_qs: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    director: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    deputy_director: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    aqso2: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    dir_aiad: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    dir_daf: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    dir_dp: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    techstores_officer: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    rq: {
        modules: ['*'],
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: true,
        canReports: true
    },
    store_officer: {
        modules: MODULES_FULL_OPS,
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: true
    },
    orderly_clerk: {
        modules: MODULES_ORDERLY,
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: true
    },
    storeman: {
        modules: MODULES_STOREMAN,
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: false
    },
    rp: {
        modules: MODULES_RP,
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: false
    },
    workshop: {
        modules: MODULES_WORKSHOP,
        canEdit: true,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: false
    },
    oc_sysadmin: {
        modules: modulesForDeptDesk('dept-sysadmin'),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_workshop: {
        modules: MODULES_WORKSHOP,
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_compengr: {
        modules: modulesForDeptDesk('dept-compengr'),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_swengr: {
        modules: modulesForDeptDesk('dept-swengr'),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_ictsec: {
        modules: modulesForDeptDesk('dept-ictsec'),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_itts: {
        modules: modulesForDeptDesk('dept-itts'),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_admin: {
        modules: modulesForDeptDesk('dept-admin', ['orderly-room']),
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    oc_gate: {
        modules: MODULES_RP,
        canEdit: true, canReleaseCut: false, canManageUsers: false, canBackup: false, canReports: false
    },
    viewer: {
        modules: MODULES_FULL_OPS,
        canEdit: false,
        canReleaseCut: false,
        canManageUsers: false,
        canBackup: false,
        canReports: true
    }
};

function createDefaultUsers() {
    return [
        { id: 'u-admin', username: 'admin', password: 'admin123', name: 'System Administrator', role: 'admin', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false },
        { id: 'u-cmd', username: 'commander', password: 'cmd123', name: 'Army Commander', role: 'army_commander', department: "ZNA COMMANDER'S OFFICE", active: true, mustChangePassword: false },
        { id: 'u-briggs', username: 'briggs', password: 'gs123', name: 'Brigadier GS', role: 'brig_gs', department: 'GS BRANCH', active: true, mustChangePassword: false },
        { id: 'u-brigas', username: 'brigas', password: 'as123', name: 'Brigadier AS', role: 'brig_as', department: 'AS BRANCH', active: true, mustChangePassword: false },
        { id: 'u-brigqs', username: 'brigqs', password: 'qs123', name: 'Brigadier QS', role: 'brig_qs', department: 'QS BRANCH', active: true, mustChangePassword: false },
        { id: 'u-dir', username: 'dir', password: 'dir123', name: 'Director IT Dir', role: 'director', department: "IT DIR DIRECTOR'S OFFICE", active: true, mustChangePassword: false },
        { id: 'u-dd', username: 'dd', password: 'dd123', name: 'Deputy Director', role: 'deputy_director', department: "IT DIR DD'S OFFICE", active: true, mustChangePassword: false },
        { id: 'u-aqso2', username: 'aqso2', password: 'aqso2123', name: 'AQSO2', role: 'aqso2', department: "IT DIR AQSO2'S OFFICE", active: true, mustChangePassword: false },
        { id: 'u-aiad', username: 'aiad', password: 'aiad123', name: 'Director AIAD', role: 'dir_aiad', department: 'AIAD', active: true, mustChangePassword: false },
        { id: 'u-daf', username: 'daf', password: 'daf123', name: 'Director DAF', role: 'dir_daf', department: 'DAF', active: true, mustChangePassword: false },
        { id: 'u-dp', username: 'dp', password: 'dp123', name: 'Director DP', role: 'dir_dp', department: 'DP', active: true, mustChangePassword: false },
        { id: 'u-tso', username: 'tso', password: 'tso123', name: 'TechStores Officer', role: 'techstores_officer', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false },
        { id: 'u-rq', username: 'rq', password: 'rq123', name: 'Regimental Quartermaster', role: 'rq', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false },
        { id: 'u-store', username: 'store', password: 'store123', name: 'Store Officer', role: 'store_officer', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false },
        { id: 'u-orderly', username: 'orderly', password: 'orderly123', name: 'Chief Clerk / Orderly Room', role: 'orderly_clerk', department: 'IT DIR ORDERLY ROOM', active: true, mustChangePassword: false },
        { id: 'u-storeman', username: 'storeman', password: 'storeman123', name: 'Storeman', role: 'storeman', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false },
        { id: 'u-rp', username: 'rp', password: 'rp123', name: 'Regimental Police', role: 'rp', department: 'IT DIR ORDERLY ROOM', active: true, mustChangePassword: false },
        { id: 'u-workshop', username: 'workshop', password: 'workshop123', name: 'Workshop NCO', role: 'workshop', department: 'IT ENGINEERING SUPPORT DEPT (WORKSHOP)', active: true, mustChangePassword: false },
        { id: 'u-sysadmin', username: 'sysadmin', password: 'sysadmin123', name: 'OC Systems Administration', role: 'oc_sysadmin', department: 'IT DIR SYSTEMS ADMINISTRATION DEPT', active: true, mustChangePassword: false },
        { id: 'u-dba', username: 'dba', password: 'dba123', name: 'OC Computer Engineering / DBA', role: 'oc_compengr', department: 'IT DIR COMPUTER ENGINEERING DEPT', active: true, mustChangePassword: false },
        { id: 'u-swengr', username: 'swengr', password: 'swengr123', name: 'OC Software Engineering', role: 'oc_swengr', department: 'IT DIR SOFTWARE ENGINEERING DEPT', active: true, mustChangePassword: false },
        { id: 'u-ictsec', username: 'ictsec', password: 'ictsec123', name: 'OC ICT Security', role: 'oc_ictsec', department: 'IT DIR ICT SECURITY DEPT', active: true, mustChangePassword: false },
        { id: 'u-itts', username: 'itts', password: 'itts123', name: 'OC ITTS', role: 'oc_itts', department: 'ITTS (INFORMATION TECHNOLOGY TRAINING SCHOOL)', active: true, mustChangePassword: false },
        { id: 'u-ao', username: 'ao', password: 'ao123', name: 'Admin Office / AO', role: 'oc_admin', department: 'IT DIR ADMIN OFFICE', active: true, mustChangePassword: false },
        { id: 'u-gate', username: 'gate', password: 'gate123', name: 'Gate Desk', role: 'oc_gate', department: 'IT DIR GATE / RP', active: true, mustChangePassword: false },
        { id: 'u-viewer', username: 'viewer', password: 'view123', name: 'Read Only Viewer', role: 'viewer', department: 'IT DIR TECHSTORES OFFICE', active: true, mustChangePassword: false }
    ];
}

/** Merge any missing seed accounts into an existing users list (by username). */
function ensureSeedUsersPresent(users) {
    const list = Array.isArray(users) ? users.slice() : [];
    const defaults = createDefaultUsers();
    defaults.forEach((seed) => {
        if (!list.some((u) => String(u.username || '').toLowerCase() === seed.username.toLowerCase())) {
            list.push({ ...seed });
        }
    });
    return list;
}

const GL_ACCOUNTS = {
    '6122100009': { defaultBudget: 50000, colorVar: '--gl-6122100009', name: 'Office Supplies & Services (ZOFF)' },
    '2200600002': { defaultBudget: 50000, colorVar: '--gl-2200600002', name: 'Computer Consumables (legacy)' },
    '2200600003': { defaultBudget: 25000, colorVar: '--gl-2200600003', name: 'Software Licenses' },
    '220200002': { defaultBudget: 35000, colorVar: '--gl-220200002', name: 'Tech Equipment Maintenance' },
    '2201900002': { defaultBudget: 20000, colorVar: '--gl-2201900002', name: 'Spare Parts' },
    '3112210001': { defaultBudget: 100000, colorVar: '--gl-3112210001', name: 'ICT Equipment' }
};

const VOUCHER_ROW_LAYOUT = {
    hasCategory: {
        category: 1, item: 2, desc: 3, qty: 4, uom: 5, gl: 6,
        unitCost: 7, lineTotal: 8, rvIv: 9, purchase: 10, supplied: 11, issued: 12, initials: 13
    },
    hasGl: {
        category: -1, item: 1, desc: 2, qty: 3, uom: 4, gl: 5,
        unitCost: 6, lineTotal: 7, rvIv: 8, purchase: 9, supplied: 10, issued: 11, initials: 12
    },
    legacy: {
        category: -1, item: 1, desc: 2, qty: 3, uom: 4, gl: -1,
        unitCost: -1, lineTotal: -1, rvIv: 5, purchase: 6, supplied: 7, issued: 8, initials: 9
    }
};

/* VOUCHER_INVENTORY_CATEGORIES is defined from the IT Directorate catalog in catalog.js */

const MODULE_IDS = [
    'gl-2200600002', 'gl-2200600003', 'gl-220200002', 'gl-2201900002', 'gl-3112210001',
    'voucher-module', 'stock-take', 'unit-checks', 'financial-year-bids', 'unit-equipment', 'ict-accountability', 'temporary-loans',
    'monthly-returns',
    'spec-evaluation', 'dp-f1-form', 'zna-q-982', 'zna-q-178', 'zna-q-1033', 'zna-q-1043',
    'zna-q-80', 'zna-svcs-890', 'zna-q-1179', 'zna-q-987', 'zna-q-3977', 'zna-svcs-1045', 'zna-q-1157',
    'zna-q-985', 'zna-q-1', 'zna-q-998', 'zna-q-1680',
    'zna-q-forms-index', 'zna-q-3', 'zna-q-31', 'zna-q-40', 'zna-q-1049', 'zna-q-1229', 'zna-q-1571', 'zna-q-1954',
    'accommodation-stores',
    'delivery-note', 'purchase-orders', 'workshop-repairs', 'gate-register', 'techstores-equipment-register', 'suppliers-contracts',
    'orderly-room', 'duties-roles', 'process-guides', 'system-help'
];

const ROW_BUILDERS = {
    'gl-2200600002-table-body': () => buildGl2200600002Row(),
    'gl-2200600003-table-body': () => buildStockLedgerRow(),
    'gl-220200002-table-body': () => buildJobCardRow(),
    'gl-2201900002-table-body': () => buildStockLedgerRow(),
    'gl-3112210001-table-body': () => buildStockLedgerRow(),
    'voucher-table-body': () => buildVoucherRow(),
    'bids-table-body': () => buildBidRow(),
    'unit-equipment-table-body': () => buildUnitEquipmentRow(),
    'loans-table-body': () => buildLoanRow(),
    'spec-eval-table-body': () => buildSpecEvalRow(),
    'dp-f1-table-body': () => buildDPF1Row(),
    'zna-q-982-table-body': () => buildZnaQ982Row(),
    'zna-q-178-table-body': () => buildZnaQ178Row(),
    'zna-q-1033-table-body': () => buildZnaQ1033Row(),
    'zna-q-1043-table-body': () => buildZnaQ1043Row(),
    'zna-q-80-table-body': () => buildZnaQ80Row(),
    'zna-svcs-890-table-body': () => buildZnaSvcs890Row(),
    'zna-q-1179-table-body': () => buildZnaQ1179Row(),
    'zna-q-987-table-body': () => buildZnaQ987Row(),
    'zna-svcs-1045-table-body': () => buildZnaSvcs1045Row(),
    'zna-q-1157-table-body': () => buildZnaQ1157Row(),
    'zna-q-985-table-body': () => buildZnaQ985Row(),
    'zna-q-1-table-body': () => buildZnaQ1Row(),
    'zna-q-998-table-body': () => buildZnaQ998Row(),
    'zna-q-1680-table-body': () => buildZnaQ1680Row(),
    'zna-q-3-table-body': () => buildZnaQ3Row(),
    'zna-q-31-table-body': () => buildZnaQ31Row(),
    'zna-q-40-table-body': () => buildZnaQ40Row(),
    'zna-q-1049-table-body': () => buildZnaQ1049Row(),
    'zna-q-1229-table-body': () => buildZnaQ1229Row(),
    'zna-q-1571-table-body': () => buildZnaQ1571Row(),
    'zna-q-1954-table-body': () => buildZnaQ1954Row(),
    'accommodation-stores-table-body': () => buildAccommodationStoreRow(),
    'delivery-table-body': () => buildDeliveryRow(),
    'purchase-orders-table-body': () => buildPurchaseOrderRow(),
    'workshop-repairs-table-body': () => buildWorkshopRepairRow(),
    'gate-register-table-body': () => buildEquipmentCustodyRow(),
    'techstores-equipment-register-table-body': () => buildEquipmentCustodyRow(),
    'suppliers-table-body': () => buildSupplierRow()
};

const STOCK_LEDGER_TBODY_IDS = [
    'gl-2200600003-table-body',
    'gl-2201900002-table-body',
    'gl-3112210001-table-body'
];
